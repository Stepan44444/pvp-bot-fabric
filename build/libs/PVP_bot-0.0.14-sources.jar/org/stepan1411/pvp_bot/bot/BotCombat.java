package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1744;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.item.*;
import java.util.*;

public class BotCombat {
    

    private static final Map<String, CombatState> combatStates = new HashMap<>();
    
    public static class CombatState {
        public class_1297 target = null;
        public String forcedTargetName = null;
        public int attackCooldown = 0;
        public int bowDrawTicks = 0;
        public boolean isDrawingBow = false;
        public class_1297 lastAttacker = null;
        public long lastAttackTime = 0;
        public WeaponMode currentMode = WeaponMode.MELEE;
        public float lastHealth = 20.0f;
        public boolean isRetreating = false;
        

        public boolean isChargingSpear = false;
        public int spearChargeTicks = 0;
        

        public int cobwebCooldown = 0;
        

        public boolean isUsingShield = false;
        public int shieldToggleCooldown = 0;
        public int airTimeTicks = 0;
        public boolean shieldBroken = false;
        public long shieldBrokenTime = 0;
        public boolean isPlacingCobweb = false;
        public int cobwebPlaceTicks = 0;
        

        public boolean isCrystalPvping = false;
        public int crystalCooldown = 0;
        public net.minecraft.class_2338 lastObsidianPos = null;
        public int crystalPvpStep = 0;
        public int crystalPvpTicks = 0;
        

        public boolean isMaceDefending = false;
        public int maceDefenseCooldown = 0;
        
        public enum WeaponMode {
            MELEE,
            RANGED,
            MACE,
            SPEAR,
            CRYSTAL,
            ANCHOR,
            ELYTRA_MACE
        }
    }
    
    public static CombatState getState(String botName) {
        return combatStates.computeIfAbsent(botName, k -> new CombatState());
    }
    
    public static void removeState(String botName) {
        combatStates.remove(botName);
    }
    
    
    public static void update(class_3222 bot, net.minecraft.server.MinecraftServer server) {
        BotSettings settings = BotSettings.get();
        if (!settings.isCombatEnabled()) return;
        
        CombatState state = getState(bot.method_5477().getString());
        

        float currentHealth = bot.method_6032();
        if (currentHealth < state.lastHealth && settings.isRevengeEnabled()) {

            class_1297 attacker = bot.method_6065();
            if (attacker != null && attacker != bot && attacker instanceof class_1309) {
                state.lastAttacker = attacker;
                state.lastAttackTime = System.currentTimeMillis();
            }
        }
        state.lastHealth = currentHealth;
        

        if (state.attackCooldown > 0) {
            state.attackCooldown--;
        }
        if (state.shieldToggleCooldown > 0) {
            state.shieldToggleCooldown--;
        }
        if (state.cobwebCooldown > 0) {
            state.cobwebCooldown--;
        }
        if (state.crystalCooldown > 0) {
            state.crystalCooldown--;
        }
        

        class_1297 target = findTarget(bot, state, settings, server);
        state.target = target;
        

        if (target != null) {
            BotDebug.showTargetEntity(bot, target);
        }

        

        if (state.isPlacingCobweb && target != null) {
            handleCobwebPlacement(bot, target, state, server);
            return;
        }
        
        if (target == null) {

            if (state.isDrawingBow) {
                stopUsingBow(bot, state);
            }

            BotNavigation.idleWander(bot);
            return;
        }
        

        BotNavigation.resetIdle(bot.method_5477().getString());
        

        double distance = bot.method_5739(target);
        

        float health = bot.method_6032();
        float maxHealth = bot.method_6063();
        float healthPercent = health / maxHealth;
        boolean lowHealth = healthPercent <= settings.getRetreatHealthPercent();
        boolean criticalHealth = healthPercent <= settings.getCriticalHealthPercent();
        

        boolean hasFood = BotUtils.hasFood(bot);
        

        if (state.shieldBroken && System.currentTimeMillis() - state.shieldBrokenTime > 5000) {
            state.shieldBroken = false;
        }
        

        var utilsState = BotUtils.getState(bot.method_5477().getString());
        
        if (utilsState.isEscapingCobweb) {
            return;
        }
        
        if (utilsState.needsToCollectWater) {
            return;
        }
        
        boolean isEating = utilsState.isEating;
        
        if (isEating && settings.isRetreatEnabled()) {

            state.isRetreating = true;
            if (state.isDrawingBow) {
                stopUsingBow(bot, state);
            }

            BotNavigation.lookAway(bot, target);
            BotNavigation.moveAway(bot, target, 1.2);
            return;
        } else if (isEating) {

            if (state.isDrawingBow) {
                stopUsingBow(bot, state);
            }

        }
        

        if (lowHealth && settings.isAutoPotionEnabled()) {
            if (BotUtils.tryUseHealingPotion(bot, server)) {

                return;
            }
        }
        




        boolean shouldRetreat = settings.isRetreatEnabled() && hasFood && 
                               (criticalHealth || (lowHealth && !state.shieldBroken));
        


        if (shouldRetreat) {
            state.isRetreating = true;
            

            if (settings.isAutoShieldEnabled()) {
                var inventory = bot.method_31548();

                class_1799 offhandItem = bot.method_6079();
                if (offhandItem.method_7960() || !offhandItem.method_7909().toString().contains("shield")) {
                    int shieldSlot = findShield(inventory);
                    if (shieldSlot >= 0) {

                        class_1799 shield = inventory.method_5438(shieldSlot);
                        inventory.method_5447(40, shield);
                        inventory.method_5447(shieldSlot, class_1799.field_8037);
                    }
                }
                

                if (!state.isUsingShield && state.shieldToggleCooldown <= 0) {
                    startUsingShield(bot, server);
                    state.isUsingShield = true;
                }
            }
            

            if (distance < 25.0) {

                if (settings.isCobwebEnabled() && distance < 8.0 && state.cobwebCooldown <= 0 && !state.isPlacingCobweb) {
                    tryPlaceCobweb(bot, target, server);
                }
                BotNavigation.lookAway(bot, target);
                BotNavigation.moveAway(bot, target, 1.5);
            }

            return;
        }
        state.isRetreating = false;
        

        if (utilsState.isMending) {
            return;
        }
        


        try {
            var strategyRegistry = org.stepan1411.pvp_bot.api.combat.CombatStrategyRegistry.getInstance();
            boolean strategyExecuted = strategyRegistry.executeStrategy(bot, target, settings, server);
            if (strategyExecuted) {

                return;
            }
        } catch (Exception e) {
            System.err.println("[PVP_BOT] Error executing combat strategy: " + e.getMessage());
            e.printStackTrace();
        }



        selectWeaponMode(bot, state, distance, settings);
        


        boolean shouldLookAt = !utilsState.isThrowingPotion;
        
        if (shouldLookAt && settings.isUseBaritone()) {

            var mainHandStack = bot.method_6047();
            boolean usingMace = mainHandStack.method_7909().toString().toLowerCase().contains("mace");
            
            if (usingMace) {

                shouldLookAt = !bot.method_24828() || distance <= 5.0;
            } else {

                shouldLookAt = distance <= 3.5;
            }
        }
        
        if (shouldLookAt) {
            BotNavigation.lookAt(bot, target);
        }
        

        double maxRange = switch (state.currentMode) {
            case MELEE -> settings.getMeleeRange() * 2;
            case RANGED -> settings.getRangedOptimalRange() + 15;
            case MACE -> settings.getMaceRange() * 2;
            case SPEAR -> settings.getSpearChargeRange();
            case CRYSTAL -> 10.0;
            case ANCHOR -> 10.0;
            case ELYTRA_MACE -> 15.0;
        };
        
        if (distance > maxRange) {

            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
            return;
        }
        

        handleMaceDefense(bot, target, settings, server);
        

        switch (state.currentMode) {
            case MELEE -> handleMeleeCombat(bot, target, state, distance, settings, server);
            case RANGED -> handleRangedCombat(bot, target, state, distance, settings, server);
            case MACE -> handleMaceCombat(bot, target, state, distance, settings, server);
            case SPEAR -> handleSpearCombat(bot, target, state, distance, settings, server);
            case CRYSTAL -> {
                boolean handled = BotCrystalPvp.doCrystalPvp(bot, target, settings, server);
                if (!handled) {
                    state.currentMode = CombatState.WeaponMode.MELEE;
                    handleMeleeCombat(bot, target, state, distance, settings, server);
                }
            }
            case ANCHOR -> {
                boolean handled = BotAnchorPvp.doAnchorPvp(bot, target, settings, server);
                if (!handled) {
                    state.currentMode = CombatState.WeaponMode.MELEE;
                    handleMeleeCombat(bot, target, state, distance, settings, server);
                }
            }
            case ELYTRA_MACE -> {

                boolean handled = BotElytraMace.doElytraMace(bot, target, settings, server);
                if (!handled) {
                    state.currentMode = CombatState.WeaponMode.MELEE;
                    handleMeleeCombat(bot, target, state, distance, settings, server);
                }
            }
        }
    }
    
    
    private static class_1297 findTarget(class_3222 bot, CombatState state, BotSettings settings, net.minecraft.server.MinecraftServer server) {

        if (state.forcedTargetName != null) {
            class_1297 forced = findEntityByName(bot, state.forcedTargetName, server);
            if (forced != null && forced.method_5805()) {
                double dist = bot.method_5739(forced);
                if (dist <= settings.getMaxTargetDistance()) {
                    return forced;
                }
            }


        }
        

        if (settings.isRevengeEnabled() && state.lastAttacker != null) {

            if (!state.lastAttacker.method_31481() && state.lastAttacker.method_5805()) {

                if (!settings.isFriendlyFireEnabled() && state.lastAttacker instanceof class_1657) {
                    String attackerName = state.lastAttacker.method_5477().getString();
                    if (BotFaction.areAllies(bot.method_5477().getString(), attackerName)) {
                        state.lastAttacker = null;
                    }
                }
                
                if (state.lastAttacker != null) {
                    double dist = bot.method_5739(state.lastAttacker);
                    if (dist <= settings.getMaxTargetDistance()) {

                        if (dist <= 10.0) {
                            state.lastAttackTime = System.currentTimeMillis();
                        }
                        return state.lastAttacker;
                    }
                }
            }

            if (state.lastAttacker == null || state.lastAttacker.method_31481() || !state.lastAttacker.method_5805() || 
                System.currentTimeMillis() - state.lastAttackTime >= 30000) {
                state.lastAttacker = null;
            }
        }
        

        if (settings.isFactionsEnabled()) {
            class_1297 factionEnemy = findFactionEnemy(bot, settings, server);
            if (factionEnemy != null) {
                return factionEnemy;
            }
        }
        

        if (settings.isAutoTargetEnabled()) {
            return findNearestEnemy(bot, settings, server);
        }
        
        return null;
    }
    
    
    private static class_1297 findFactionEnemy(class_3222 bot, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        String botName = bot.method_5477().getString();
        String botFaction = BotFaction.getFaction(botName);
        

        if (botFaction == null) return null;
        
        double maxDist = settings.getMaxTargetDistance();
        class_1297 nearest = null;
        double nearestDist = maxDist + 1;
        
        if (server != null) {
            for (var player : server.method_3760().method_14571()) {
                if (player == bot) continue;
                if (!player.method_5805()) continue;
                if (player.method_7325() || player.method_68878()) continue;
                
                String targetName = player.method_5477().getString();
                

                if (BotFaction.areEnemies(botName, targetName)) {
                    double dist = bot.method_5739(player);
                    if (dist < nearestDist && dist <= maxDist) {
                        nearestDist = dist;
                        nearest = player;
                    }
                }
            }
        }
        
        return nearest;
    }
    
    private static class_1297 findEntityByName(class_3222 bot, String name, net.minecraft.server.MinecraftServer server) {

        if (server != null) {
            var player = server.method_3760().method_14566(name);
            if (player != null && player != bot) return player;
        }
        

        if (server != null) {
            for (var world : server.method_3738()) {
                for (class_1297 entity : world.method_27909()) {
                    if (entity.method_5477().getString().equalsIgnoreCase(name) && entity != bot) {
                        return entity;
                    }
                }
            }
        }
        return null;
    }
    
    private static class_1297 findNearestEnemy(class_3222 bot, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        double maxDist = settings.getMaxTargetDistance();
        class_238 searchBox = bot.method_5829().method_1014(maxDist);
        
        class_1297 nearest = null;
        double nearestDist = maxDist + 1;
        

        if (server != null) {
            for (var world : server.method_3738()) {
                for (class_1297 entity : world.method_8335(bot, searchBox)) {
                    if (!isValidTarget(bot, entity, settings)) continue;
                    
                    double dist = bot.method_5739(entity);
                    if (dist < nearestDist) {
                        nearestDist = dist;
                        nearest = entity;
                    }
                }
            }
        }
        
        return nearest;
    }
    
    private static boolean isValidTarget(class_3222 bot, class_1297 entity, BotSettings settings) {
        if (entity == bot) return false;
        if (!entity.method_5805()) return false;
        if (!(entity instanceof class_1309 living)) return false;
        
        String botName = bot.method_5477().getString();
        

        if (entity instanceof class_1657 player) {
            if (player.method_7325() || player.method_68878()) return false;
            
            String targetName = player.method_5477().getString();
            

            if (settings.isFactionsEnabled()) {

                if (!settings.isFriendlyFireEnabled() && BotFaction.areAllies(botName, targetName)) {
                    return false;
                }

                if (BotFaction.areEnemies(botName, targetName)) {
                    return true;
                }
            }
            

            if (BotManager.getAllBots().contains(targetName)) {
                if (!settings.isTargetOtherBots()) return false;
            } else {
                if (!settings.isTargetPlayers()) return false;
            }
            
            return true;
        }
        

        if (entity instanceof class_1588) {
            return settings.isTargetHostileMobs();
        }
        

        if (living instanceof net.minecraft.class_1308) {
            return settings.isTargetHostileMobs();
        }
        
        return false;
    }

    
    
    private static void selectWeaponMode(class_3222 bot, CombatState state, double distance, BotSettings settings) {
        var inventory = bot.method_31548();
        class_1297 target = state.target;
        
        boolean hasMelee = findMeleeWeapon(inventory) >= 0;
        boolean hasRanged = findRangedWeapon(inventory) >= 0;
        boolean hasMace = findMace(inventory) >= 0;
        boolean hasSpear = findSpear(inventory) >= 0;
        
        double meleeRange = settings.getMeleeRange();
        double rangedMinRange = settings.getRangedMinRange();
        double maceRange = settings.getMaceRange();
        double spearRange = settings.getSpearRange();
        

        if (target != null && BotElytraMace.canUseElytraMace(bot, target, settings)) {
            state.currentMode = CombatState.WeaponMode.ELYTRA_MACE;
        } else if (target != null && BotCrystalPvp.canUseCrystalPvp(bot, target, settings)) {
            state.currentMode = CombatState.WeaponMode.CRYSTAL;
        } else if (target != null && BotAnchorPvp.canUseAnchorPvp(bot, target, settings)) {
            state.currentMode = CombatState.WeaponMode.ANCHOR;
        } else if (hasMace && distance <= maceRange && settings.isMaceEnabled()) {
            state.currentMode = CombatState.WeaponMode.MACE;
        } else if (hasSpear && distance <= spearRange && settings.isSpearEnabled()) {
            state.currentMode = CombatState.WeaponMode.SPEAR;
        } else if (hasRanged && distance > rangedMinRange && settings.isRangedEnabled()) {
            state.currentMode = CombatState.WeaponMode.RANGED;
        } else if (hasMelee && distance <= meleeRange * 2) {
            state.currentMode = CombatState.WeaponMode.MELEE;
        } else if (hasSpear && settings.isSpearEnabled()) {
            state.currentMode = CombatState.WeaponMode.SPEAR;
        } else if (hasRanged && settings.isRangedEnabled()) {
            state.currentMode = CombatState.WeaponMode.RANGED;
        } else {
            state.currentMode = CombatState.WeaponMode.MELEE;
        }
    }
    
    
    private static boolean isTargetMaceAttacking(class_1297 target) {
        if (!(target instanceof class_1657 player)) return false;
        

        class_1799 mainHand = player.method_6047();
        boolean hasMace = mainHand.method_7909() == class_1802.field_49814;
        
        if (!hasMace) return false;
        

        boolean inAir = !player.method_24828();
        if (!inAir) return false;
        

        double velocityY = player.method_18798().field_1351;
        



        boolean willAttackSoon = velocityY < -0.08;
        
        if (willAttackSoon) {
            System.out.println("[MACE_DETECTION] " + player.method_5477().getString() + " attacking with mace! (vel: " + String.format("%.2f", velocityY) + ")");
        }
        
        return willAttackSoon;
    }
    
    
    private static void handleMaceDefense(class_3222 bot, class_1297 target, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        if (!settings.isShieldMace()) {
            return;
        }
        
        var inventory = bot.method_31548();
        var utilsState = BotUtils.getState(bot.method_5477().getString());
        var combatState = getState(bot.method_5477().getString());
        

        if (combatState.maceDefenseCooldown > 0) {
            combatState.maceDefenseCooldown--;
        }
        
        boolean isMaceAttacking = isTargetMaceAttacking(target);
        
        if (isMaceAttacking) {

            combatState.maceDefenseCooldown = 20;
            combatState.isMaceDefending = true;
            System.out.println("[MACE_DEFENSE] " + bot.method_5477().getString() + " detected mace attack from " + target.method_5477().getString() + "! Settings: shieldmace=" + settings.isShieldMace());
        }
        

        boolean shouldDefend = combatState.isMaceDefending && combatState.maceDefenseCooldown > 0;
        
        if (!shouldDefend) {

            if (combatState.isUsingShield && combatState.isMaceDefending) {
                try {
                    server.method_3734().method_9235().execute(
                        "player " + bot.method_5477().getString() + " stop", 
                        server.method_3739()
                    );
                    System.out.println("[MACE_DEFENSE] " + bot.method_5477().getString() + " stopped defending (cooldown expired)");
                } catch (Exception e) {
                    bot.method_6021();
                }
                combatState.isUsingShield = false;
                combatState.isMaceDefending = false;
            }
            return;
        }
        

        int shieldSlot = findShield(inventory);
        if (shieldSlot < 0) {
            System.out.println("[MACE_DEFENSE] " + bot.method_5477().getString() + " has no shield!");
            return;
        }
        

        class_1799 offhand = inventory.method_5438(40);
        boolean hasTotem = offhand.method_7909() == class_1802.field_8288;
        
        if (hasTotem && !settings.isPreferShieldMace()) {
            System.out.println("[MACE_DEFENSE] " + bot.method_5477().getString() + " has totem and preferShieldMace is false, skipping");
            return;
        }
        

        if (settings.isShieldMainHand() && hasTotem) {

            if (shieldSlot != 0) {
                class_1799 shield = inventory.method_5438(shieldSlot);
                class_1799 current = inventory.method_5438(0);
                inventory.method_5447(shieldSlot, current);
                inventory.method_5447(0, shield);
                shieldSlot = 0;
                System.out.println("[MACE_DEFENSE] " + bot.method_5477().getString() + " moved shield to main hand (slot 0)");
            }
            

            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, 0);
            

            if (!combatState.isUsingShield) {
                try {
                    server.method_3734().method_9235().execute(
                        "player " + bot.method_5477().getString() + " use continuous", 
                        server.method_3739()
                    );
                    System.out.println("[MACE_DEFENSE] " + bot.method_5477().getString() + " activating shield in main hand");
                } catch (Exception e) {
                    bot.method_6019(class_1268.field_5808);
                }
                combatState.isUsingShield = true;
            }
        } else {

            if (shieldSlot != 40) {
                class_1799 shield = inventory.method_5438(shieldSlot);
                class_1799 current = inventory.method_5438(40);
                inventory.method_5447(shieldSlot, current);
                inventory.method_5447(40, shield);
                System.out.println("[MACE_DEFENSE] " + bot.method_5477().getString() + " moved shield to offhand");
            }
            

            if (!combatState.isUsingShield) {
                try {
                    server.method_3734().method_9235().execute(
                        "player " + bot.method_5477().getString() + " use continuous", 
                        server.method_3739()
                    );
                    System.out.println("[MACE_DEFENSE] " + bot.method_5477().getString() + " activating shield in offhand");
                } catch (Exception e) {
                    bot.method_6019(class_1268.field_5810);
                }
                combatState.isUsingShield = true;
            }
        }
    }
    
    
    private static void handleMeleeCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        var utilsState = BotUtils.getState(bot.method_5477().getString());
        

        if (state.isMaceDefending && state.maceDefenseCooldown > 0) {

            lookAtTarget(bot, target);
            return;
        }
        
        if (utilsState.isEating) {
            System.out.println("[COMBAT] " + bot.method_5477().getString() + " is eating, skipping combat");
            return;
        }
        
        var inventory = bot.method_31548();
        

        if (state.isDrawingBow) {
            stopUsingBow(bot, state);
        }
        
        double meleeRange = settings.getMeleeRange();
        

        if (settings.isCobwebEnabled() && distance < 6.0 && distance > 2.0 && state.cobwebCooldown <= 0 && !state.isPlacingCobweb) {

            if (target instanceof net.minecraft.class_1309 living) {
                class_243 targetVel = living.method_18798();
                double targetSpeed = Math.sqrt(targetVel.field_1352 * targetVel.field_1352 + targetVel.field_1350 * targetVel.field_1350);
                if (targetSpeed > 0.08) {
                    tryPlaceCobweb(bot, target, server);
                }
            }
        }
        

        if (distance > meleeRange) {
            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
        } else if (distance < 1.5) {

            BotNavigation.moveAway(bot, target, 0.3);
        }
        

        float healthPercent = bot.method_6032() / bot.method_6063();
        boolean shouldUseShield = settings.isAutoShieldEnabled() && healthPercent < settings.getShieldHealthThreshold();
        


        boolean willAttackSoon = distance <= meleeRange && state.attackCooldown == 1;
        boolean shouldHoldShield = shouldUseShield && !willAttackSoon;
        
        if (shouldUseShield) {

            class_1799 offhandItem = bot.method_6079();
            if (offhandItem.method_7960() || !offhandItem.method_7909().toString().contains("shield")) {
                int shieldSlot = findShield(inventory);
                if (shieldSlot >= 0) {

                    class_1799 shield = inventory.method_5438(shieldSlot);
                    inventory.method_5447(40, shield);
                    inventory.method_5447(shieldSlot, class_1799.field_8037);
                }
            }
            

            if (shouldHoldShield && !state.isUsingShield) {

                startUsingShield(bot, server);
                state.isUsingShield = true;
            } else if (!shouldHoldShield && state.isUsingShield) {

                stopUsingShield(bot, server);
                state.isUsingShield = false;
            }
        } else {

            if (state.isUsingShield && state.shieldToggleCooldown <= 0) {
                stopUsingShield(bot, server);
                state.isUsingShield = false;
                state.shieldToggleCooldown = 20;
            }
        }

        if (distance <= meleeRange && state.attackCooldown <= 0) {
            

            if (bot.method_7261(0.5f) < 1.0f) {
                return;
            }
            

            if (settings.isShieldBreakEnabled() && target instanceof class_1657 player && player.method_6039()) {

                int axeSlot = findAxe(inventory);
                if (axeSlot >= 0) {

                    if (axeSlot >= 9) {
                        class_1799 axe = inventory.method_5438(axeSlot);
                        class_1799 current = inventory.method_5438(0);
                        inventory.method_5447(axeSlot, current);
                        inventory.method_5447(0, axe);
                        axeSlot = 0;
                    }
                    org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, axeSlot);
                    

                    attackWithCarpet(bot, target, server);
                    

                    state.shieldBroken = true;
                    state.shieldBrokenTime = System.currentTimeMillis();
                    

                    int cooldown = shouldUseShield ? (int)(settings.getAttackCooldown() * 1.5) : settings.getAttackCooldown();
                    state.attackCooldown = cooldown;
                    


                    return;
                }
            }
            

            int currentSlot = org.stepan1411.pvp_bot.utils.InventoryHelper.getSelectedSlot(inventory);
            class_1799 currentItem = inventory.method_5438(currentSlot);
            double currentScore = getMeleeScore(currentItem.method_7909(), settings.isPreferSword());
            
            int weaponSlot = findMeleeWeapon(inventory);
            if (weaponSlot >= 0 && weaponSlot < 9) {

                class_1799 newWeapon = inventory.method_5438(weaponSlot);
                double newScore = getMeleeScore(newWeapon.method_7909(), settings.isPreferSword());
                
                if (newScore > currentScore || currentScore == 0) {
                    org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, weaponSlot);
                }
            }
            

            if (settings.isCriticalsEnabled()) {
                if (bot.method_24828()) {
                    bot.method_6043();
                    return;
                } else {
                    double velocityY = bot.method_18798().field_1351;
                    

                    if (velocityY < 0) {
                        attackWithCarpet(bot, target, server);
                        
                        int cooldown = shouldUseShield ? (int)(settings.getAttackCooldown() * 1.5) : settings.getAttackCooldown();
                        state.attackCooldown = cooldown;
                    }
                }
            } else {
                attackWithCarpet(bot, target, server);
                
                int cooldown = shouldUseShield ? (int)(settings.getAttackCooldown() * 1.5) : settings.getAttackCooldown();
                state.attackCooldown = cooldown;
            }
        } else {

            int currentSlot = org.stepan1411.pvp_bot.utils.InventoryHelper.getSelectedSlot(inventory);
            class_1799 currentItem = inventory.method_5438(currentSlot);
            double currentScore = getMeleeScore(currentItem.method_7909(), settings.isPreferSword());
            
            int weaponSlot = findMeleeWeapon(inventory);
            if (weaponSlot >= 0 && weaponSlot < 9) {

                class_1799 newWeapon = inventory.method_5438(weaponSlot);
                double newScore = getMeleeScore(newWeapon.method_7909(), settings.isPreferSword());
                
                if (newScore > currentScore || currentScore == 0) {
                    org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, weaponSlot);
                }
            }
        }
    }
    
    
    private static void handleRangedCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings, net.minecraft.server.MinecraftServer server) {


        if (state.isMaceDefending && state.maceDefenseCooldown > 0) {
            lookAtTarget(bot, target);
            return;
        }

        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (utilsState.isEating) {
            return;
        }
        
        var inventory = bot.method_31548();
        

        int bowSlot = findRangedWeapon(inventory);
        if (bowSlot >= 0 && bowSlot < 9) {
            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, bowSlot);
        }
        

        if (!hasArrows(inventory)) {

            state.currentMode = CombatState.WeaponMode.MELEE;
            return;
        }
        
        class_1799 weapon = bot.method_6047();
        boolean isCrossbow = weapon.method_7909() instanceof class_1764;
        
        if (isCrossbow) {
            handleCrossbowCombat(bot, target, state, distance, settings);
        } else {
            handleBowCombat(bot, target, state, distance, settings);
        }
        

        double optimalRange = settings.getRangedOptimalRange();
        if (distance < optimalRange - 5) {

            double dx = bot.method_23317() - target.method_23317();
            double dz = bot.method_23321() - target.method_23321();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > 0) {
                dx /= dist;
                dz /= dist;
                bot.method_5762(dx * settings.getMoveSpeed() * 0.05, 0, dz * settings.getMoveSpeed() * 0.05);

            }
        } else if (distance > optimalRange + 10) {
            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
        }
    }
    
    private static void handleBowCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings) {
        if (!state.isDrawingBow) {

            bot.method_6019(class_1268.field_5808);
            state.isDrawingBow = true;
            state.bowDrawTicks = 0;
        } else {
            state.bowDrawTicks++;
            

            int minDrawTime = settings.getBowMinDrawTime();
            if (state.bowDrawTicks >= minDrawTime) {

                bot.method_6075();
                state.isDrawingBow = false;
                state.bowDrawTicks = 0;
                state.attackCooldown = 5;
            }
        }
    }
    
    private static void handleCrossbowCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings) {
        class_1799 crossbow = bot.method_6047();
        
        if (class_1764.method_7781(crossbow)) {

            bot.method_6075();
            state.attackCooldown = 5;
            state.isDrawingBow = false;
        } else if (!state.isDrawingBow) {

            bot.method_6019(class_1268.field_5808);
            state.isDrawingBow = true;
            state.bowDrawTicks = 0;
        } else {
            state.bowDrawTicks++;

            if (state.bowDrawTicks >= 25) {
                bot.method_6075();
                state.isDrawingBow = false;
            }
        }
    }
    
    private static void stopUsingBow(class_3222 bot, CombatState state) {
        if (state.isDrawingBow) {
            bot.method_6075();
            state.isDrawingBow = false;
            state.bowDrawTicks = 0;
        }
    }
    
    
    private static void handleMaceCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings, net.minecraft.server.MinecraftServer server) {


        if (state.isMaceDefending && state.maceDefenseCooldown > 0) {
            lookAtTarget(bot, target);
            return;
        }

        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (utilsState.isEating) {
            return;
        }
        
        var inventory = bot.method_31548();
        
        if (state.isDrawingBow) {
            stopUsingBow(bot, state);
        }
        

        if (!bot.method_24828()) {
            int maceSlot = findMace(inventory);
            if (maceSlot >= 0 && maceSlot < 9) {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, maceSlot);
            }
            


            double verticalSpeed = bot.method_18798().field_1351;
            if (verticalSpeed < 0 && distance <= 5.0 && state.attackCooldown <= 0) {

                attackWithCarpet(bot, target, server);
                state.attackCooldown = 5;
            }
            return;
        }
        

        if (bot.method_24828() && distance <= settings.getMaceRange()) {

            int windChargeSlot = findWindCharge(inventory);
            
            if (windChargeSlot >= 0) {

                BotUtils.useWindCharge(bot, server);
                bot.method_6043();
            } else {

                int maceSlot = findMace(inventory);
                if (maceSlot >= 0 && maceSlot < 9) {
                    org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, maceSlot);
                }
                
                bot.method_6043();
                double dx = target.method_23317() - bot.method_23317();
                double dz = target.method_23321() - bot.method_23321();
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > 0) {
                    dx /= dist;
                    dz /= dist;
                }
                bot.method_5762(dx * 0.3, 0.3, dz * 0.3);
            }
        }
        

        if (bot.method_24828() && distance <= 3.5 && state.attackCooldown <= 0) {
            int maceSlot = findMace(inventory);
            if (maceSlot >= 0 && maceSlot < 9) {
                org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, maceSlot);
            }
            attackWithCarpet(bot, target, server);
            state.attackCooldown = settings.getAttackCooldown();
        }
        

        if (distance > settings.getMaceRange()) {
            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
        }
    }
    
    
    private static void handleSpearCombat(class_3222 bot, class_1297 target, CombatState state, double distance, BotSettings settings, net.minecraft.server.MinecraftServer server) {


        if (state.isMaceDefending && state.maceDefenseCooldown > 0) {
            lookAtTarget(bot, target);
            return;
        }

        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (utilsState.isEating) {
            return;
        }
        
        var inventory = bot.method_31548();
        

        if (state.isDrawingBow) {
            stopUsingBow(bot, state);
        }
        

        int spearSlot = findSpear(inventory);
        if (spearSlot >= 0 && spearSlot < 9) {
            org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, spearSlot);
        }
        
        double chargeStartDistance = 10.0;
        double chargeHitDistance = 0.1;
        





        
        if (distance > chargeStartDistance) {

            if (state.isChargingSpear) {
                bot.method_6075();
                state.isChargingSpear = false;
                state.spearChargeTicks = 0;
            }
            BotNavigation.moveToward(bot, target, settings.getMoveSpeed());
            
        } else if (distance > chargeHitDistance) {

            if (!state.isChargingSpear) {

                bot.method_6019(class_1268.field_5808);
                state.isChargingSpear = true;
                state.spearChargeTicks = 0;
            }
            
            state.spearChargeTicks++;
            

            BotNavigation.moveToward(bot, target, settings.getMoveSpeed() * 1.3);
            

            if (state.spearChargeTicks > 60) {

                bot.method_6075();
                state.isChargingSpear = false;
                state.spearChargeTicks = 0;
            }
            
        } else {

            if (state.isChargingSpear) {

                bot.method_6075();
                state.isChargingSpear = false;
                state.spearChargeTicks = 0;

                state.attackCooldown = 0;
            }
            

            BotNavigation.moveAway(bot, target, settings.getMoveSpeed());
        }
    }

    
    private static final java.util.Random random = new java.util.Random();
    
    
    private static void attack(class_3222 bot, class_1297 target) {
        BotSettings settings = BotSettings.get();
        

        try {
            boolean cancelled = org.stepan1411.pvp_bot.api.BotAPIIntegration.fireAttackEvent(bot, target);
            if (cancelled) {
                return;
            }
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error firing attack event: " + e.getMessage());
        }
        

        if (random.nextInt(100) < settings.getMissChance()) {

            bot.method_6104(class_1268.field_5808);
            return;
        }
        
        bot.method_7324(target);
        bot.method_6104(class_1268.field_5808);
    }
    
    
    private static void attackWithCarpet(class_3222 bot, class_1297 target, net.minecraft.server.MinecraftServer server) {
        BotSettings settings = BotSettings.get();
        
        var utilsState = BotUtils.getState(bot.method_5477().getString());
        if (!BotUtils.canAttack(bot, utilsState)) {
            System.out.println("[COMBAT] " + bot.method_5477().getString() + " cannot attack - cobweb escape active");
            bot.method_6104(class_1268.field_5808);
            return;
        }

        boolean cancelled = org.stepan1411.pvp_bot.api.BotAPIIntegration.fireAttackEvent(bot, target);
        if (cancelled) {
            System.out.println("[COMBAT] " + bot.method_5477().getString() + " attack cancelled by API");
            bot.method_6104(class_1268.field_5808);
            return;
        }


        if (!settings.isFriendlyFireEnabled() && target instanceof class_1657) {
            String botName = bot.method_5477().getString();
            String targetName = target.method_5477().getString();
            if (BotFaction.areAllies(botName, targetName)) {
                System.out.println("[COMBAT] " + bot.method_5477().getString() + " skipping ally " + targetName);
                bot.method_6104(class_1268.field_5808);
                return;
            }
        }
        

        if (random.nextInt(100) < settings.getMissChance()) {
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " swinghand", 
                    server.method_3739()
                );
            } catch (Exception e) {
                bot.method_6104(class_1268.field_5808);
            }
            return;
        }
        

        if (random.nextInt(100) < settings.getMistakeChance()) {
            float yawOffset = (random.nextFloat() - 0.5f) * 60;
            bot.method_36456(bot.method_36454() + yawOffset);
        }
        

        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " attack once", 
                server.method_3739()
            );
        } catch (Exception e) {
            bot.method_6104(class_1268.field_5808);
        }
    }
    
    
    private static void startUsingShield(class_3222 bot, net.minecraft.server.MinecraftServer server) {
        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " use continuous", 
                server.method_3739()
            );
        } catch (Exception e) {

            bot.method_6019(class_1268.field_5810);
        }
    }
    
    
    private static void stopUsingShield(class_3222 bot, net.minecraft.server.MinecraftServer server) {
        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " stop", 
                server.method_3739()
            );
        } catch (Exception e) {

            bot.method_6021();
        }
    }
    
    
    private static void lookAtTarget(class_3222 bot, class_1297 target) {
        class_243 targetPos = target.method_33571();
        class_243 botPos = bot.method_33571();
        
        double dx = targetPos.field_1352 - botPos.field_1352;
        double dy = targetPos.field_1351 - botPos.field_1351;
        double dz = targetPos.field_1350 - botPos.field_1350;
        
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) (class_3532.method_15349(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(class_3532.method_15349(dy, horizontalDist) * (180.0 / Math.PI));
        
        bot.method_36456(yaw);
        bot.method_36457(pitch);
        bot.method_5847(yaw);
    }
    
    
    private static void lookAwayFromTarget(class_3222 bot, class_1297 target) {
        class_243 targetPos = target.method_33571();
        class_243 botPos = bot.method_33571();
        

        double dx = botPos.field_1352 - targetPos.field_1352;
        double dz = botPos.field_1350 - targetPos.field_1350;
        
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) (class_3532.method_15349(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        
        bot.method_36456(yaw);
        bot.method_36457(0);
        bot.method_5847(yaw);
    }
    
    
    private static void moveToward(class_3222 bot, class_1297 target, double speed) {
        double botX = bot.method_23317(), botY = bot.method_23318(), botZ = bot.method_23321();
        double targetX = target.method_23317(), targetY = target.method_23318(), targetZ = target.method_23321();
        double dx = targetX - botX;
        double dz = targetZ - botZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 0) {
            dx /= dist;
            dz /= dist;
        }
        
        bot.method_5728(true);
        bot.field_6250 = (float) speed;
        bot.field_6212 = 0;
        

        if (bot.method_24828()) {
            bot.method_5762(dx * speed * 0.1, 0, dz * speed * 0.1);
        }
    }
    
    
    private static void moveAway(class_3222 bot, class_1297 target, double speed) {
        double botX = bot.method_23317(), botY = bot.method_23318(), botZ = bot.method_23321();
        double targetX = target.method_23317(), targetY = target.method_23318(), targetZ = target.method_23321();
        double dx = botX - targetX;
        double dz = botZ - targetZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > 0) {
            dx /= dist;
            dz /= dist;
        }
        

        bot.method_5728(true);
        bot.field_6250 = (float) speed;
        
        if (bot.method_24828()) {
            bot.method_5762(dx * speed * 0.1, 0, dz * speed * 0.1);
        }
    }
    

    
    private static int findMeleeWeapon(net.minecraft.class_1661 inventory) {
        BotSettings settings = BotSettings.get();
        boolean preferSword = settings.isPreferSword();
        
        int bestSlot = -1;
        double bestScore = 0;
        
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            class_1792 item = stack.method_7909();
            double score = getMeleeScore(item, preferSword);
            
            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }
        
        return bestSlot;
    }
    
    
    private static int findAxe(net.minecraft.class_1661 inventory) {
        int bestSlot = -1;
        double bestDamage = 0;
        
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            
            class_1792 item = stack.method_7909();
            if (item instanceof class_1743) {
                double damage = getAxeDamage(item);
                if (damage > bestDamage) {
                    bestDamage = damage;
                    bestSlot = i;
                }
            }
        }
        
        return bestSlot;
    }
    
    
    private static int findShield(net.minecraft.class_1661 inventory) {

        if (inventory.method_5438(40).method_7909() == class_1802.field_8255) return 40;
        

        for (int i = 0; i < 36; i++) {
            if (inventory.method_5438(i).method_7909() == class_1802.field_8255) return i;
        }
        return -1;
    }
    
    private static double getAxeDamage(class_1792 item) {
        if (item == class_1802.field_22025) return 10;
        if (item == class_1802.field_8556) return 9;
        if (item == class_1802.field_8475) return 9;
        if (item == class_1802.field_8062) return 9;
        if (item == class_1802.field_8825) return 7;
        if (item == class_1802.field_8406) return 7;
        return 0;
    }
    
    
    private static double getMeleeScore(class_1792 item, boolean preferSword) {
        double baseDamage = getMeleeDamage(item);
        if (baseDamage == 0) return 0;
        

        if (preferSword && isSword(item)) {
            return baseDamage + 5;
        }
        
        return baseDamage;
    }
    
    
    private static boolean isSword(class_1792 item) {
        return item == class_1802.field_22022 || 
               item == class_1802.field_8802 || 
               item == class_1802.field_8371 || 
               item == class_1802.field_8845 || 
               item == class_1802.field_8528 || 
               item == class_1802.field_8091;
    }
    
    private static double getMeleeDamage(class_1792 item) {
        if (item == class_1802.field_22022) return 8;
        if (item == class_1802.field_22025) return 10;
        if (item == class_1802.field_8802) return 7;
        if (item == class_1802.field_8556) return 9;
        if (item == class_1802.field_8371) return 6;
        if (item == class_1802.field_8475) return 9;
        if (item == class_1802.field_8528) return 5;
        if (item == class_1802.field_8062) return 9;
        if (item == class_1802.field_8845) return 4;
        if (item == class_1802.field_8825) return 7;
        if (item == class_1802.field_8091) return 4;
        if (item == class_1802.field_8406) return 7;
        if (item == class_1802.field_8547) return 9;
        return 0;
    }
    
    private static int findRangedWeapon(net.minecraft.class_1661 inventory) {

        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() instanceof class_1764) return i;
        }
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() instanceof class_1753) return i;
        }
        return -1;
    }
    
    private static int findMace(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_49814) return i;
        }
        return -1;
    }
    
    private static int findWindCharge(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_49098) return i;
        }
        return -1;
    }
    
    
    private static int findSpear(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);

            String itemName = stack.method_7909().toString().toLowerCase();
            if (itemName.contains("spear")) return i;
        }
        return -1;
    }
    
    
    private static int findCobweb(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8786) return i;
        }
        return -1;
    }
    
    
    private static boolean tryPlaceCobweb(class_3222 bot, class_1297 target, net.minecraft.server.MinecraftServer server) {
        CombatState state = getState(bot.method_5477().getString());
        

        if (state.isPlacingCobweb) return false;
        
        var inventory = bot.method_31548();
        int cobwebSlot = findCobweb(inventory);
        if (cobwebSlot < 0) return false;
        

        var world = bot.method_51469();
        net.minecraft.class_2338 targetPos = target.method_24515();
        if (world.method_8320(targetPos).method_26204() == net.minecraft.class_2246.field_10343) {
            return false;
        }
        

        if (cobwebSlot >= 9) {
            class_1799 cobweb = inventory.method_5438(cobwebSlot);
            class_1799 current = inventory.method_5438(0);
            inventory.method_5447(cobwebSlot, current);
            inventory.method_5447(0, cobweb);
            cobwebSlot = 0;
        }
        

        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, cobwebSlot);
        

        state.isPlacingCobweb = true;
        state.cobwebPlaceTicks = 0;
        
        return true;
    }
    
    
    private static void handleCobwebPlacement(class_3222 bot, class_1297 target, CombatState state, net.minecraft.server.MinecraftServer server) {
        state.cobwebPlaceTicks++;
        

        class_243 targetFeet = new class_243(target.method_23317(), target.method_23318() - 0.5, target.method_23321());
        class_243 botPos = bot.method_33571();
        
        double dx = targetFeet.field_1352 - botPos.field_1352;
        double dy = targetFeet.field_1351 - botPos.field_1351;
        double dz = targetFeet.field_1350 - botPos.field_1350;
        
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) (Math.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(Math.atan2(dy, horizontalDist) * (180.0 / Math.PI));
        
        bot.method_36456(yaw);
        bot.method_36457(pitch);
        bot.method_5847(yaw);
        

        if (state.cobwebPlaceTicks % 2 == 0 && state.cobwebPlaceTicks <= 6) {
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use once", 
                    server.method_3739()
                );
            } catch (Exception e) {

            }
        }
        

        if (state.cobwebPlaceTicks >= 8) {
            state.isPlacingCobweb = false;
            state.cobwebPlaceTicks = 0;
            state.cobwebCooldown = 20;
        }
    }
    
    private static boolean hasArrows(net.minecraft.class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() instanceof class_1744) return true;
        }
        return false;
    }
    

    
    
    public static void setTarget(String botName, String targetName) {
        CombatState state = getState(botName);
        state.forcedTargetName = targetName;
    }
    
    
    public static void clearTarget(String botName) {
        CombatState state = getState(botName);
        state.forcedTargetName = null;
        state.target = null;
        state.lastAttacker = null;
        state.lastAttackTime = 0;
        state.isRetreating = false;
    }
    
    
    public static void onBotDamaged(class_3222 bot, class_1282 source) {

        class_1297 attacker = source.method_5529();
        if (attacker == null) {
            attacker = source.method_5526();
        }
        if (attacker == null || attacker == bot) return;
        

        if (!(attacker instanceof class_1309)) return;
        
        CombatState state = getState(bot.method_5477().getString());
        state.lastAttacker = attacker;
        state.lastAttackTime = System.currentTimeMillis();
    }
    
    
    public static class_1297 getTarget(String botName) {
        return getState(botName).target;
    }
}
