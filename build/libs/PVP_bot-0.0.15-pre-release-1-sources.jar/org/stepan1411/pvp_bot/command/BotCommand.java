package org.stepan1411.pvp_bot.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import org.stepan1411.pvp_bot.bot.BotCombat;
import org.stepan1411.pvp_bot.bot.BotFaction;
import org.stepan1411.pvp_bot.bot.BotKits;
import org.stepan1411.pvp_bot.bot.BotManager;
import org.stepan1411.pvp_bot.bot.BotNameGenerator;
import org.stepan1411.pvp_bot.bot.BotPath;
import org.stepan1411.pvp_bot.bot.BotSettings;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class BotCommand {

    private static final SuggestionProvider<class_2168> BOT_SUGGESTIONS =
        (ctx, builder) -> {
            for (String bot : BotManager.getAllBots()) {
                builder.suggest(bot);
            }
            return builder.buildFuture();
        };

    private static final SuggestionProvider<class_2168> KIT_SUGGESTIONS =
        (ctx, builder) -> {
            for (String kit : BotKits.getKitNames()) {
                builder.suggest(kit);
            }
            return builder.buildFuture();
        };

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("pvpbot")
            .requires(s -> true)

            // ========== SPAWN ==========
            .then(class_2170.method_9247("spawn")
                .executes(ctx -> spawn(ctx, null))
                .then(class_2170.method_9244("name", StringArgumentType.word())
                    .executes(ctx -> spawn(ctx, StringArgumentType.getString(ctx, "name")))))

            // ========== REMOVE ==========
            .then(class_2170.method_9247("remove")
                .then(class_2170.method_9244("name", StringArgumentType.word())
                    .suggests(BOT_SUGGESTIONS)
                    .executes(BotCommand::remove)))

            // ========== REMOVEALL ==========
            .then(class_2170.method_9247("reload")
                .executes(BotCommand::reload))
            .then(class_2170.method_9247("removeall")
                .executes(BotCommand::removeAll))

            // ========== SETTINGS ==========
            .then(buildSettings())

            // ========== BOT-MANAGEMENT ==========
            .then(class_2170.method_9247("bot-management")
                .then(class_2170.method_9247("mass-spawn")
                    .then(class_2170.method_9244("count", IntegerArgumentType.integer(1, 50))
                        .executes(BotCommand::massSpawn)))
                .then(class_2170.method_9247("attack")
                    .then(class_2170.method_9244("botname", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        .then(class_2170.method_9244("target", StringArgumentType.word())
                            .executes(BotCommand::botAttack))))
                .then(class_2170.method_9247("stop-attack")
                    .then(class_2170.method_9244("botname", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        .executes(BotCommand::botStopAttack)))
                .then(class_2170.method_9247("inventory")
                    .then(class_2170.method_9244("botname", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        .executes(BotCommand::botInventory)))
                .then(class_2170.method_9247("list")
                    .executes(BotCommand::botList))
                .then(class_2170.method_9247("path")
                    .then(class_2170.method_9247("create")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(BotCommand::pathCreate)))
                    .then(class_2170.method_9247("delete")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(BotCommand::pathDelete)))
                    .then(class_2170.method_9247("addpoint")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(BotCommand::pathAddPoint)))
                    .then(class_2170.method_9247("removepoint")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .then(class_2170.method_9244("index", IntegerArgumentType.integer())
                                .executes(BotCommand::pathRemovePoint))
                            .executes(BotCommand::pathRemovePointLast)))
                    .then(class_2170.method_9247("clear")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(BotCommand::pathClear)))
                    .then(class_2170.method_9247("loop")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                .executes(BotCommand::pathLoop))))
                    .then(class_2170.method_9247("attack")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                .executes(BotCommand::pathAttack))))
                    .then(class_2170.method_9247("start")
                        .then(class_2170.method_9244("bot", StringArgumentType.word())
                            .suggests(BOT_SUGGESTIONS)
                            .then(class_2170.method_9244("path", StringArgumentType.word())
                                .executes(BotCommand::pathStart))))
                    .then(class_2170.method_9247("stop")
                        .then(class_2170.method_9244("bot", StringArgumentType.word())
                            .suggests(BOT_SUGGESTIONS)
                            .executes(BotCommand::pathStop)))
                    .then(class_2170.method_9247("list")
                        .executes(BotCommand::pathList))
                    .then(class_2170.method_9247("show")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .then(class_2170.method_9244("visible", BoolArgumentType.bool())
                                .executes(BotCommand::pathShow))))
                    .then(class_2170.method_9247("info")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(BotCommand::pathInfo)))
                    .then(class_2170.method_9247("distribute")
                        .then(class_2170.method_9244("path", StringArgumentType.word())
                            .executes(BotCommand::pathDistribute)))
                    .then(class_2170.method_9247("startnear")
                        .then(class_2170.method_9244("path", StringArgumentType.word())
                            .then(class_2170.method_9244("radius", DoubleArgumentType.doubleArg(1))
                                .executes(BotCommand::pathStartNear))))
                    .then(class_2170.method_9247("stopall")
                        .then(class_2170.method_9244("path", StringArgumentType.word())
                            .executes(BotCommand::pathStopAll)))))

            // ========== KIT ==========
            .then(class_2170.method_9247("kit")
                .then(class_2170.method_9247("create-kit")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .executes(BotCommand::kitCreate)))
                .then(class_2170.method_9247("delete-kit")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(KIT_SUGGESTIONS)
                        .executes(BotCommand::kitDelete)))
                .then(class_2170.method_9247("give-kit")
                    .then(class_2170.method_9244("playername", StringArgumentType.word())
                        .then(class_2170.method_9244("kitname", StringArgumentType.word())
                            .suggests(KIT_SUGGESTIONS)
                            .executes(BotCommand::kitGive))))
                .then(class_2170.method_9247("kits")
                    .executes(BotCommand::kitList)))

            // ========== FACTION ==========
            .then(class_2170.method_9247("faction")
                .then(class_2170.method_9247("list")
                    .executes(BotCommand::factionList))
                .then(class_2170.method_9247("create")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .executes(BotCommand::factionCreate)))
                .then(class_2170.method_9247("delete")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .executes(BotCommand::factionDelete)))
                .then(class_2170.method_9247("add")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .then(class_2170.method_9244("player", StringArgumentType.word())
                            .executes(BotCommand::factionAdd))))
                .then(class_2170.method_9247("remove")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .then(class_2170.method_9244("player", StringArgumentType.word())
                            .executes(BotCommand::factionRemove))))
                .then(class_2170.method_9247("hostile")
                    .then(class_2170.method_9244("faction1", StringArgumentType.word())
                        .then(class_2170.method_9244("faction2", StringArgumentType.word())
                            .then(class_2170.method_9244("hostile", BoolArgumentType.bool())
                                .executes(ctx -> factionHostile(ctx, BoolArgumentType.getBool(ctx, "hostile"))))
                            .executes(ctx -> factionHostile(ctx, true)))))
                .then(class_2170.method_9247("info")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .executes(BotCommand::factionInfo)))
                .then(class_2170.method_9247("addnear")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .then(class_2170.method_9244("radius", DoubleArgumentType.doubleArg(1, 10000))
                            .executes(BotCommand::factionAddNear))))
                .then(class_2170.method_9247("addall")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .executes(BotCommand::factionAddAll)))
                .then(class_2170.method_9247("give")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .then(class_2170.method_9244("item", StringArgumentType.greedyString())
                            .executes(BotCommand::factionGive))))
                .then(class_2170.method_9247("attack")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .then(class_2170.method_9244("target", StringArgumentType.word())
                            .executes(BotCommand::factionAttack))))
                .then(class_2170.method_9247("startpath")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .then(class_2170.method_9244("path", StringArgumentType.word())
                            .executes(BotCommand::factionStartPath))))
                .then(class_2170.method_9247("stoppath")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .executes(BotCommand::factionStopPath)))
                .then(class_2170.method_9247("givekit")
                    .then(class_2170.method_9244("faction", StringArgumentType.word())
                        .then(class_2170.method_9244("kitname", StringArgumentType.word())
                            .suggests(KIT_SUGGESTIONS)
                            .executes(BotCommand::factionGiveKit)))))
        );
    }

    // ========== SETTINGS BUILDER ==========

    private static LiteralArgumentBuilder<class_2168> buildSettings() {
        var settings = class_2170.method_9247("settings")
            .executes(BotCommand::settings);

        settings.then(boolSetting("autoarmor", () -> BotSettings.get().isAutoEquipArmor(), v -> BotSettings.get().setAutoEquipArmor(v)));
        settings.then(boolSetting("autoweapon", () -> BotSettings.get().isAutoEquipWeapon(), v -> BotSettings.get().setAutoEquipWeapon(v)));
        settings.then(boolSetting("droparmor", () -> BotSettings.get().isDropWorseArmor(), v -> BotSettings.get().setDropWorseArmor(v)));
        settings.then(boolSetting("dropweapon", () -> BotSettings.get().isDropWorseWeapons(), v -> BotSettings.get().setDropWorseWeapons(v)));
        settings.then(doubleSetting("dropdistance", () -> BotSettings.get().getDropDistance(), v -> BotSettings.get().setDropDistance(v), 1.0, 10.0));
        settings.then(intSetting("interval", () -> BotSettings.get().getCheckInterval(), v -> BotSettings.get().setCheckInterval(v), 1, 100));
        settings.then(intSetting("minarmorlevel", () -> BotSettings.get().getMinArmorLevel(), v -> BotSettings.get().setMinArmorLevel(v), 0, 100));
        settings.then(boolSetting("combat", () -> BotSettings.get().isCombatEnabled(), v -> BotSettings.get().setCombatEnabled(v)));
        settings.then(boolSetting("revenge", () -> BotSettings.get().isRevengeEnabled(), v -> BotSettings.get().setRevengeEnabled(v)));
        settings.then(boolSetting("autotarget", () -> BotSettings.get().isAutoTargetEnabled(), v -> BotSettings.get().setAutoTargetEnabled(v)));
        settings.then(boolSetting("targetplayers", () -> BotSettings.get().isTargetPlayers(), v -> BotSettings.get().setTargetPlayers(v)));
        settings.then(boolSetting("targetmobs", () -> BotSettings.get().isTargetHostileMobs(), v -> BotSettings.get().setTargetHostileMobs(v)));
        settings.then(boolSetting("targetbots", () -> BotSettings.get().isTargetOtherBots(), v -> BotSettings.get().setTargetOtherBots(v)));
        settings.then(boolSetting("criticals", () -> BotSettings.get().isCriticalsEnabled(), v -> BotSettings.get().setCriticalsEnabled(v)));
        settings.then(boolSetting("ranged", () -> BotSettings.get().isRangedEnabled(), v -> BotSettings.get().setRangedEnabled(v)));
        settings.then(boolSetting("mace", () -> BotSettings.get().isMaceEnabled(), v -> BotSettings.get().setMaceEnabled(v)));
        settings.then(boolSetting("elytramace", () -> BotSettings.get().isElytraMaceEnabled(), v -> BotSettings.get().setElytraMaceEnabled(v)));
        settings.then(boolSetting("specialnames", () -> BotSettings.get().isUseSpecialNames(), v -> BotSettings.get().setUseSpecialNames(v)));
        settings.then(intSetting("elytramaceretries", () -> BotSettings.get().getElytraMaceMaxRetries(), v -> BotSettings.get().setElytraMaceMaxRetries(v), 1, 10));
        settings.then(intSetting("elytramacealtitude", () -> BotSettings.get().getElytraMaceMinAltitude(), v -> BotSettings.get().setElytraMaceMinAltitude(v), 5, 50));
        settings.then(doubleSetting("elytramacedistance", () -> BotSettings.get().getElytraMaceAttackDistance(), v -> BotSettings.get().setElytraMaceAttackDistance(v), 3.0, 15.0));
        settings.then(intSetting("elytramacefireworks", () -> BotSettings.get().getElytraMaceFireworkCount(), v -> BotSettings.get().setElytraMaceFireworkCount(v), 1, 10));
        settings.then(boolSetting("shieldmace", () -> BotSettings.get().isShieldMace(), v -> BotSettings.get().setShieldMace(v)));
        settings.then(boolSetting("prefershieldmace", () -> BotSettings.get().isPreferShieldMace(), v -> BotSettings.get().setPreferShieldMace(v)));
        settings.then(boolSetting("shieldmainhand", () -> BotSettings.get().isShieldMainHand(), v -> BotSettings.get().setShieldMainHand(v)));
        settings.then(intSetting("attackcooldown", () -> BotSettings.get().getAttackCooldown(), v -> BotSettings.get().setAttackCooldown(v), 1, 40));
        settings.then(doubleSetting("meleerange", () -> BotSettings.get().getMeleeRange(), v -> BotSettings.get().setMeleeRange(v), 2.0, 6.0));
        settings.then(doubleSetting("movespeed", () -> BotSettings.get().getMoveSpeed(), v -> BotSettings.get().setMoveSpeed(v), 0.1, 2.0));
        settings.then(boolSetting("autototem", () -> BotSettings.get().isAutoTotemEnabled(), v -> BotSettings.get().setAutoTotemEnabled(v)));
        settings.then(boolSetting("totempriority", () -> BotSettings.get().isTotemPriority(), v -> BotSettings.get().setTotemPriority(v)));
        settings.then(boolSetting("autoshield", () -> BotSettings.get().isAutoShieldEnabled(), v -> BotSettings.get().setAutoShieldEnabled(v)));
        settings.then(boolSetting("autopotion", () -> BotSettings.get().isAutoPotionEnabled(), v -> BotSettings.get().setAutoPotionEnabled(v)));
        settings.then(boolSetting("shieldbreak", () -> BotSettings.get().isShieldBreakEnabled(), v -> BotSettings.get().setShieldBreakEnabled(v)));
        settings.then(boolSetting("prefersword", () -> BotSettings.get().isPreferSword(), v -> BotSettings.get().setPreferSword(v)));
        settings.then(boolSetting("bhop", () -> BotSettings.get().isBhopEnabled(), v -> BotSettings.get().setBhopEnabled(v)));
        settings.then(intSetting("bhopcooldown", () -> BotSettings.get().getBhopCooldown(), v -> BotSettings.get().setBhopCooldown(v), 5, 30));
        settings.then(doubleSetting("jumpboost", () -> BotSettings.get().getJumpBoost(), v -> BotSettings.get().setJumpBoost(v), 0.0, 0.5));
        settings.then(boolSetting("idle", () -> BotSettings.get().isIdleWanderEnabled(), v -> BotSettings.get().setIdleWanderEnabled(v)));
        settings.then(doubleSetting("idleradius", () -> BotSettings.get().getIdleWanderRadius(), v -> BotSettings.get().setIdleWanderRadius(v), 3.0, 50.0));
        settings.then(boolSetting("friendlyfire", () -> BotSettings.get().isFriendlyFireEnabled(), v -> BotSettings.get().setFriendlyFireEnabled(v)));
        settings.then(intSetting("misschance", () -> BotSettings.get().getMissChance(), v -> BotSettings.get().setMissChance(v), 0, 100));
        settings.then(intSetting("mistakechance", () -> BotSettings.get().getMistakeChance(), v -> BotSettings.get().setMistakeChance(v), 0, 100));
        settings.then(intSetting("reactiondelay", () -> BotSettings.get().getReactionDelay(), v -> BotSettings.get().setReactionDelay(v), 0, 20));
        settings.then(boolSetting("retreat", () -> BotSettings.get().isRetreatEnabled(), v -> BotSettings.get().setRetreatEnabled(v)));
        settings.then(boolSetting("autoeat", () -> BotSettings.get().isAutoEatEnabled(), v -> BotSettings.get().setAutoEatEnabled(v)));
        settings.then(boolSetting("automend", () -> BotSettings.get().isAutoMendEnabled(), v -> BotSettings.get().setAutoMendEnabled(v)));
        settings.then(boolSetting("botLeaveOnDeath", () -> BotSettings.get().isBotLeaveOnDeath(), v -> BotSettings.get().setBotLeaveOnDeath(v)));
        settings.then(boolSetting("attackInvincible", () -> BotSettings.get().isAttackInvincible(), v -> BotSettings.get().setAttackInvincible(v)));
        settings.then(doubleSetting("viewdistance", () -> BotSettings.get().getMaxTargetDistance(), v -> BotSettings.get().setMaxTargetDistance(v), 5.0, 128.0));

        return settings;
    }

    // ========== SETTING HELPERS ==========

    private static LiteralArgumentBuilder<class_2168> boolSetting(String name, BooleanSupplier getter, Consumer<Boolean> setter) {
        return class_2170.method_9247(name)
            .executes(ctx -> {
                ctx.getSource().method_9226(() -> class_2561.method_43470(name + ": " + getter.getAsBoolean()), false);
                return 1;
            })
            .then(class_2170.method_9244("value", BoolArgumentType.bool())
                .executes(ctx -> {
                    boolean value = BoolArgumentType.getBool(ctx, "value");
                    setter.accept(value);
                    ctx.getSource().method_9226(() -> class_2561.method_43470(name + ": " + value), true);
                    return 1;
                }));
    }

    private static LiteralArgumentBuilder<class_2168> intSetting(String name, java.util.function.IntSupplier getter, java.util.function.IntConsumer setter, int min, int max) {
        return class_2170.method_9247(name)
            .executes(ctx -> {
                ctx.getSource().method_9226(() -> class_2561.method_43470(name + ": " + getter.getAsInt()), false);
                return 1;
            })
            .then(class_2170.method_9244("value", IntegerArgumentType.integer(min, max))
                .executes(ctx -> {
                    int value = IntegerArgumentType.getInteger(ctx, "value");
                    setter.accept(value);
                    ctx.getSource().method_9226(() -> class_2561.method_43470(name + ": " + value), true);
                    return 1;
                }));
    }

    private static LiteralArgumentBuilder<class_2168> doubleSetting(String name, java.util.function.DoubleSupplier getter, java.util.function.DoubleConsumer setter, double min, double max) {
        return class_2170.method_9247(name)
            .executes(ctx -> {
                ctx.getSource().method_9226(() -> class_2561.method_43470(name + ": " + getter.getAsDouble()), false);
                return 1;
            })
            .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg(min, max))
                .executes(ctx -> {
                    double value = DoubleArgumentType.getDouble(ctx, "value");
                    setter.accept(value);
                    ctx.getSource().method_9226(() -> class_2561.method_43470(name + ": " + value), true);
                    return 1;
                }));
    }

    // ========== COMMAND HANDLERS ==========

    private static int spawn(CommandContext<class_2168> ctx, String name) {
        var source = ctx.getSource();
        String botName = name != null ? name : BotNameGenerator.generateUniqueName();
        var server = source.method_9211();
        var existingPlayer = server.method_3760().method_14566(botName);
        if (existingPlayer != null && !BotManager.getAllBots().contains(botName)) {
            source.method_9213(class_2561.method_43470("Cannot create bot '" + botName + "': a real player with this name is online!"));
            return 0;
        }
        if (BotManager.spawnBot(server, botName, source)) {
            source.method_9226(() -> class_2561.method_43470("PvP Bot '" + botName + "' spawned!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to spawn bot '" + botName + "' (bot already exists or name is taken)"));
            return 0;
        }
    }

    private static int massSpawn(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        var server = source.method_9211();
        int count = IntegerArgumentType.getInteger(ctx, "count");
        source.method_9226(() -> class_2561.method_43470("Spawning " + count + " bots "), false);
        int[] spawned = {0};
        int[] current = {0};
        scheduleSpawn(server, source, count, spawned, current);
        return 1;
    }

    private static void scheduleSpawn(net.minecraft.server.MinecraftServer server, class_2168 source, int total, int[] spawned, int[] current) {
        if (current[0] >= total) {
            source.method_9226(() -> class_2561.method_43470("Finished! Spawned " + spawned[0] + " bots."), true);
            return;
        }
        String name = BotNameGenerator.generateUniqueName();
        if (BotManager.spawnBot(server, name, source)) {
            spawned[0]++;
        }
        current[0]++;
        server.execute(() -> {
            int[] delay = {0};
            server.execute(new Runnable() {
                @Override
                public void run() {
                    delay[0]++;
                    if (delay[0] < 5) {
                        server.execute(this);
                    } else {
                        scheduleSpawn(server, source, total, spawned, current);
                    }
                }
            });
        });
    }

    private static int remove(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        if (BotManager.removeBot(source.method_9211(), name, source)) {
            source.method_9226(() -> class_2561.method_43470("Bot '" + name + "' removed!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Bot '" + name + "' not found!"));
            return 0;
        }
    }

    private static int removeAll(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        int count = BotManager.getBotCount();
        BotManager.removeAllBots(source.method_9211(), source);
        source.method_9226(() -> class_2561.method_43470("Removed " + count + " bots"), true);
        return count;
    }

    private static int reload(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        var server = source.method_9211();
        BotSettings.load();
        BotKits.reload(server);
        BotPath.init();
        BotManager.reloadBots();
        source.method_9226(() -> class_2561.method_43470("All configurations reloaded!"), true);
        return 1;
    }

    private static int settings(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        BotSettings s = BotSettings.get();
        source.method_9226(() -> class_2561.method_43470("=== Equipment Settings ==="), false);
        source.method_9226(() -> class_2561.method_43470("autoarmor: " + s.isAutoEquipArmor()), false);
        source.method_9226(() -> class_2561.method_43470("autoweapon: " + s.isAutoEquipWeapon()), false);
        source.method_9226(() -> class_2561.method_43470("droparmor: " + s.isDropWorseArmor()), false);
        source.method_9226(() -> class_2561.method_43470("dropweapon: " + s.isDropWorseWeapons()), false);
        source.method_9226(() -> class_2561.method_43470("dropdistance: " + s.getDropDistance()), false);
        source.method_9226(() -> class_2561.method_43470("interval: " + s.getCheckInterval() + " ticks"), false);
        source.method_9226(() -> class_2561.method_43470("minarmorlevel: " + s.getMinArmorLevel()), false);
        source.method_9226(() -> class_2561.method_43470("=== Combat Settings ==="), false);
        source.method_9226(() -> class_2561.method_43470("combat: " + s.isCombatEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("revenge: " + s.isRevengeEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("autotarget: " + s.isAutoTargetEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("targetplayers: " + s.isTargetPlayers()), false);
        source.method_9226(() -> class_2561.method_43470("targetmobs: " + s.isTargetHostileMobs()), false);
        source.method_9226(() -> class_2561.method_43470("targetbots: " + s.isTargetOtherBots()), false);
        source.method_9226(() -> class_2561.method_43470("criticals: " + s.isCriticalsEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("ranged: " + s.isRangedEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("mace: " + s.isMaceEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("elytramace: " + s.isElytraMaceEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("specialnames: " + s.isUseSpecialNames()), false);
        source.method_9226(() -> class_2561.method_43470("elytramaceretries: " + s.getElytraMaceMaxRetries()), false);
        source.method_9226(() -> class_2561.method_43470("elytramacealtitude: " + s.getElytraMaceMinAltitude()), false);
        source.method_9226(() -> class_2561.method_43470("elytramacedistance: " + s.getElytraMaceAttackDistance()), false);
        source.method_9226(() -> class_2561.method_43470("elytramacefireworks: " + s.getElytraMaceFireworkCount()), false);
        source.method_9226(() -> class_2561.method_43470("shieldmace: " + s.isShieldMace()), false);
        source.method_9226(() -> class_2561.method_43470("prefershieldmace: " + s.isPreferShieldMace()), false);
        source.method_9226(() -> class_2561.method_43470("shieldmainhand: " + s.isShieldMainHand()), false);
        source.method_9226(() -> class_2561.method_43470("attackcooldown: " + s.getAttackCooldown() + " ticks"), false);
        source.method_9226(() -> class_2561.method_43470("meleerange: " + s.getMeleeRange()), false);
        source.method_9226(() -> class_2561.method_43470("movespeed: " + s.getMoveSpeed()), false);
        source.method_9226(() -> class_2561.method_43470("=== Utilities ==="), false);
        source.method_9226(() -> class_2561.method_43470("autototem: " + s.isAutoTotemEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("totempriority: " + s.isTotemPriority() + " (don't replace totem with shield)"), false);
        source.method_9226(() -> class_2561.method_43470("autoshield: " + s.isAutoShieldEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("autopotion: " + s.isAutoPotionEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("shieldbreak: " + s.isShieldBreakEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("prefersword: " + s.isPreferSword()), false);
        source.method_9226(() -> class_2561.method_43470("botLeaveOnDeath: " + s.isBotLeaveOnDeath()), false);
        source.method_9226(() -> class_2561.method_43470("attackInvincible: " + s.isAttackInvincible()), false);
        source.method_9226(() -> class_2561.method_43470("=== Navigation Settings ==="), false);
        source.method_9226(() -> class_2561.method_43470("bhop: " + s.isBhopEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("bhopcooldown: " + s.getBhopCooldown() + " ticks"), false);
        source.method_9226(() -> class_2561.method_43470("jumpboost: " + s.getJumpBoost()), false);
        source.method_9226(() -> class_2561.method_43470("idle: " + s.isIdleWanderEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("idleradius: " + s.getIdleWanderRadius()), false);
        source.method_9226(() -> class_2561.method_43470("=== Factions & Mistakes ==="), false);
        source.method_9226(() -> class_2561.method_43470("factions: " + s.isFactionsEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("friendlyfire: " + s.isFriendlyFireEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("misschance: " + s.getMissChance() + "%"), false);
        source.method_9226(() -> class_2561.method_43470("mistakechance: " + s.getMistakeChance() + "%"), false);
        source.method_9226(() -> class_2561.method_43470("reactiondelay: " + s.getReactionDelay() + " ticks"), false);
        return 1;
    }

    // ========== BOT-MANAGEMENT HANDLERS ==========

    private static int botAttack(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String botname = StringArgumentType.getString(ctx, "botname");
        String target = StringArgumentType.getString(ctx, "target");
        if (!BotManager.getAllBots().contains(botname)) {
            source.method_9213(class_2561.method_43470("Bot '" + botname + "' not found!"));
            return 0;
        }
        BotCombat.setTarget(botname, target);
        source.method_9226(() -> class_2561.method_43470("Bot '" + botname + "' now attacking '" + target + "'"), true);
        return 1;
    }

    private static int botStopAttack(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String botname = StringArgumentType.getString(ctx, "botname");
        if (!BotManager.getAllBots().contains(botname)) {
            source.method_9213(class_2561.method_43470("Bot '" + botname + "' not found!"));
            return 0;
        }
        BotCombat.clearTarget(botname);
        source.method_9226(() -> class_2561.method_43470("Bot '" + botname + "' stopped attacking"), true);
        return 1;
    }

    private static int botInventory(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String botname = StringArgumentType.getString(ctx, "botname");
        if (!BotManager.getAllBots().contains(botname)) {
            source.method_9213(class_2561.method_43470("Bot '" + botname + "' not found!"));
            return 0;
        }
        var bot = source.method_9211().method_3760().method_14566(botname);
        if (bot == null) {
            source.method_9213(class_2561.method_43470("Bot '" + botname + "' not online!"));
            return 0;
        }
        var inventory = bot.method_31548();
        source.method_9226(() -> class_2561.method_43470("=== Inventory: " + botname + " ==="), false);
        StringBuilder hotbar = new StringBuilder("Hotbar: ");
        for (int i = 0; i < 9; i++) {
            var stack = inventory.method_5438(i);
            if (!stack.method_7960()) {
                hotbar.append("[").append(stack.method_7964().getString()).append(" x").append(stack.method_7947()).append("] ");
            }
        }
        source.method_9226(() -> class_2561.method_43470(hotbar.toString().trim()), false);
        StringBuilder mainInv = new StringBuilder("Main: ");
        for (int i = 9; i < 36; i++) {
            var stack = inventory.method_5438(i);
            if (!stack.method_7960()) {
                mainInv.append("[").append(stack.method_7964().getString()).append(" x").append(stack.method_7947()).append("] ");
            }
        }
        source.method_9226(() -> class_2561.method_43470(mainInv.toString().trim()), false);
        StringBuilder armor = new StringBuilder("Armor: ");
        for (int i = 36; i < 40; i++) {
            var stack = inventory.method_5438(i);
            if (!stack.method_7960()) {
                armor.append("[").append(stack.method_7964().getString()).append("] ");
            }
        }
        String armorStr = armor.toString().trim();
        if (!armorStr.equals("Armor:")) {
            source.method_9226(() -> class_2561.method_43470(armorStr), false);
        }
        var offhand = inventory.method_5438(40);
        if (!offhand.method_7960()) {
            source.method_9226(() -> class_2561.method_43470("Offhand: [" + offhand.method_7964().getString() + " x" + offhand.method_7947() + "]"), false);
        }
        source.method_9226(() -> class_2561.method_43470("HP: " + String.format("%.1f", bot.method_6032()) + "/" + String.format("%.1f", bot.method_6063()) +
            " | Food: " + bot.method_7344().method_7586() +
            " | XP: " + bot.field_7520), false);
        return 1;
    }

    private static int botList(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        var bots = BotManager.getAllBots();
        if (bots.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No active PvP bots"), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("Active PvP bots (" + bots.size() + "):"), false);
            for (String botName : bots) {
                source.method_9226(() -> class_2561.method_43470(" - " + botName), false);
            }
        }
        return bots.size();
    }

    // ========== PATH HANDLERS ==========

    private static int pathCreate(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        if (BotPath.createPath(name)) {
            BotPath.setPathVisible(name, true);
            source.method_9226(() -> class_2561.method_43470("Path '" + name + "' created"), true);
            source.method_9226(() -> class_2561.method_43470("Visualization enabled. To disable: /pvpbot path show " + name + " false"), false);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Path '" + name + "' already exists"));
            return 0;
        }
    }

    private static int pathDelete(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        if (BotPath.deletePath(name)) {
            source.method_9226(() -> class_2561.method_43470("Path '" + name + "' deleted"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Path '" + name + "' not found"));
            return 0;
        }
    }

    private static int pathAddPoint(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("Only players can add path points"));
            return 0;
        }
        class_243 pos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
        if (BotPath.addPoint(name, pos)) {
            var path = BotPath.getPath(name);
            if (!BotPath.isPathVisible(name)) {
                BotPath.setPathVisible(name, true);
                source.method_9226(() -> class_2561.method_43470("Visualization enabled. To disable: /pvpbot path show " + name + " false"), false);
            }
            source.method_9226(() -> class_2561.method_43470(String.format("Point #%d added to path '%s' at (%.1f, %.1f, %.1f)", path.points.size(), name, pos.field_1352, pos.field_1351, pos.field_1350)), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Path '" + name + "' not found"));
            return 0;
        }
    }

    private static int pathRemovePoint(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        int index = IntegerArgumentType.getInteger(ctx, "index");
        if (BotPath.removePoint(name, index)) {
            source.method_9226(() -> class_2561.method_43470("Point #" + index + " removed from path '" + name + "'"), true);
            return 1;
        }
        source.method_9213(class_2561.method_43470("Invalid path or index"));
        return 0;
    }

    private static int pathRemovePointLast(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        if (BotPath.removeLastPoint(name)) {
            source.method_9226(() -> class_2561.method_43470("Last point removed from path '" + name + "'"), true);
            return 1;
        }
        source.method_9213(class_2561.method_43470("Invalid path or index"));
        return 0;
    }

    private static int pathClear(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        if (BotPath.clearPath(name)) {
            source.method_9226(() -> class_2561.method_43470("All points cleared from path '" + name + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Path '" + name + "' not found"));
            return 0;
        }
    }

    private static int pathLoop(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        boolean value = BoolArgumentType.getBool(ctx, "value");
        if (BotPath.setLoop(name, value)) {
            source.method_9226(() -> class_2561.method_43470("Path '" + name + "' loop: " + value), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Path '" + name + "' not found"));
            return 0;
        }
    }

    private static int pathAttack(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        boolean value = BoolArgumentType.getBool(ctx, "value");
        if (BotPath.setAttack(name, value)) {
            if (value) {
                source.method_9226(() -> class_2561.method_43470("Path '" + name + "' attack: enabled"), true);
            } else {
                source.method_9226(() -> class_2561.method_43470("Path '" + name + "' attack: disabled"), true);
                source.method_9226(() -> class_2561.method_43470("Bot will ignore attacks and continue following path"), false);
            }
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Path '" + name + "' not found"));
            return 0;
        }
    }

    private static int pathStart(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String bot = StringArgumentType.getString(ctx, "bot");
        String path = StringArgumentType.getString(ctx, "path");
        if (BotPath.startFollowing(bot, path)) {
            source.method_9226(() -> class_2561.method_43470("Bot '" + bot + "' started following path '" + path + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Path '" + path + "' not found or empty"));
            return 0;
        }
    }

    private static int pathStop(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String bot = StringArgumentType.getString(ctx, "bot");
        if (BotPath.stopFollowing(bot)) {
            source.method_9226(() -> class_2561.method_43470("Bot '" + bot + "' stopped following path"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Bot '" + bot + "' is not following any path"));
            return 0;
        }
    }

    private static int pathList(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        var paths = BotPath.getAllPaths();
        if (paths.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No paths created"), false);
            return 0;
        }
        source.method_9226(() -> class_2561.method_43470("=== Paths ==="), false);
        for (var entry : paths.entrySet()) {
            String name = entry.getKey();
            var path = entry.getValue();
            source.method_9226(() -> class_2561.method_43470(String.format("%s: %d points, loop: %s, attack: %s", name, path.points.size(), path.loop, path.attack)), false);
        }
        return paths.size();
    }

    private static int pathShow(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        boolean visible = BoolArgumentType.getBool(ctx, "visible");
        if (BotPath.setPathVisible(name, visible)) {
            if (visible) {
                source.method_9226(() -> class_2561.method_43470("Path '" + name + "' visualization enabled"), true);
                source.method_9226(() -> class_2561.method_43470("To disable: /pvpbot path show " + name + " false"), false);
            } else {
                source.method_9226(() -> class_2561.method_43470("Path '" + name + "' visualization disabled"), true);
            }
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Path '" + name + "' not found"));
            return 0;
        }
    }

    private static int pathInfo(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        var path = BotPath.getPath(name);
        if (path == null) {
            source.method_9213(class_2561.method_43470("Path '" + name + "' not found"));
            return 0;
        }
        source.method_9226(() -> class_2561.method_43470("=== Path: " + name + " ==="), false);
        source.method_9226(() -> class_2561.method_43470("Points: " + path.points.size()), false);
        source.method_9226(() -> class_2561.method_43470("Loop: " + path.loop), false);
        source.method_9226(() -> class_2561.method_43470("Attack: " + path.attack), false);
        for (int i = 0; i < path.points.size(); i++) {
            var point = path.points.get(i);
            int index = i;
            source.method_9226(() -> class_2561.method_43470(String.format("#%d: (%.1f, %.1f, %.1f)", index, point.field_1352, point.field_1351, point.field_1350)), false);
        }
        return 1;
    }

    private static int pathDistribute(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String pathName = StringArgumentType.getString(ctx, "path");
        var path = BotPath.getPath(pathName);
        if (path == null) {
            source.method_9213(class_2561.method_43470("Path '" + pathName + "' not found"));
            return 0;
        }
        if (path.points.isEmpty()) {
            source.method_9213(class_2561.method_43470("Path '" + pathName + "' has no points"));
            return 0;
        }
        var server = source.method_9211();
        var botsOnPath = new java.util.ArrayList<String>();
        for (String botName : BotManager.getAllBots()) {
            if (BotPath.isFollowing(botName, pathName)) {
                botsOnPath.add(botName);
            }
        }
        if (botsOnPath.isEmpty()) {
            source.method_9213(class_2561.method_43470("No bots are following path '" + pathName + "'"));
            return 0;
        }
        int totalPoints = path.points.size();
        int botCount = botsOnPath.size();
        for (int i = 0; i < botCount; i++) {
            String botName = botsOnPath.get(i);
            int pointIndex = (i * totalPoints) / botCount;
            BotPath.setBotPathIndex(botName, pointIndex);
            var point = path.points.get(pointIndex);
            try {
                String tpCommand = String.format(java.util.Locale.US, "tp %s %.2f %.2f %.2f", botName, point.field_1352, point.field_1351 + 1.0, point.field_1350);
                server.method_3734().method_9235().execute(tpCommand, server.method_3739());
            } catch (Exception e) {
            }
        }
        source.method_9226(() -> class_2561.method_43470("Distributed " + botCount + " bots along path '" + pathName + "'"), true);
        return botCount;
    }

    private static int pathStartNear(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String pathName = StringArgumentType.getString(ctx, "path");
        double radius = DoubleArgumentType.getDouble(ctx, "radius");
        var path = BotPath.getPath(pathName);
        if (path == null) {
            source.method_9213(class_2561.method_43470("Path '" + pathName + "' not found"));
            return 0;
        }
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("This command can only be used by a player"));
            return 0;
        }
        var server = source.method_9211();
        int started = 0;
        for (String botName : BotManager.getAllBots()) {
            class_3222 bot = server.method_3760().method_14566(botName);
            if (bot != null && bot.method_5739(player) <= radius) {
                if (BotPath.startFollowing(botName, pathName)) {
                    started++;
                }
            }
        }
        if (started > 0) {
            int finalStarted = started;
            source.method_9226(() -> class_2561.method_43470("Started path '" + pathName + "' for " + finalStarted + " bots within " + radius + " blocks"), true);
            return started;
        } else {
            source.method_9213(class_2561.method_43470("No bots found within " + radius + " blocks"));
            return 0;
        }
    }

    private static int pathStopAll(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String pathName = StringArgumentType.getString(ctx, "path");
        var path = BotPath.getPath(pathName);
        if (path == null) {
            source.method_9213(class_2561.method_43470("Path '" + pathName + "' not found"));
            return 0;
        }
        int stopped = 0;
        for (String botName : BotManager.getAllBots()) {
            if (BotPath.isFollowing(botName, pathName)) {
                if (BotPath.stopFollowing(botName)) {
                    stopped++;
                }
            }
        }
        if (stopped > 0) {
            int finalStopped = stopped;
            source.method_9226(() -> class_2561.method_43470("Stopped " + finalStopped + " bots on path '" + pathName + "'"), true);
            return stopped;
        } else {
            source.method_9213(class_2561.method_43470("No bots are following path '" + pathName + "'"));
            return 0;
        }
    }

    // ========== KIT HANDLERS ==========

    private static int kitCreate(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        var player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("This command must be run by a player!"));
            return 0;
        }
        if (BotKits.kitExists(name)) {
            source.method_9213(class_2561.method_43470("Kit '" + name + "' already exists!"));
            return 0;
        }
        if (BotKits.createKit(name, player)) {
            source.method_9226(() -> class_2561.method_43470("Kit '" + name + "' created from your inventory!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to create kit (empty inventory?)"));
            return 0;
        }
    }

    private static int kitDelete(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        if (BotKits.deleteKit(name)) {
            source.method_9226(() -> class_2561.method_43470("Kit '" + name + "' deleted!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Kit '" + name + "' not found!"));
            return 0;
        }
    }

    private static int kitGive(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String playername = StringArgumentType.getString(ctx, "playername");
        String kitname = StringArgumentType.getString(ctx, "kitname");
        if (!BotKits.kitExists(kitname)) {
            source.method_9213(class_2561.method_43470("Kit '" + kitname + "' not found!"));
            return 0;
        }
        var player = source.method_9211().method_3760().method_14566(playername);
        if (player == null) {
            source.method_9213(class_2561.method_43470("Player '" + playername + "' not found!"));
            return 0;
        }
        if (BotKits.giveKit(kitname, player)) {
            source.method_9226(() -> class_2561.method_43470("Gave kit '" + kitname + "' to '" + playername + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to give kit!"));
            return 0;
        }
    }

    private static int kitList(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        var kits = BotKits.getKitNames();
        if (kits.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No kits created. Use /pvpbot kit create-kit <name> to create one."), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("Kits (" + kits.size() + "): " + String.join(", ", kits)), false);
        }
        return 1;
    }

    // ========== FACTION HANDLERS ==========

    private static int factionList(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        var factions = BotFaction.getAllFactions();
        if (factions.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No factions created"), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("Factions (" + factions.size() + "):"), false);
            for (String faction : factions) {
                var members = BotFaction.getMembers(faction);
                var enemies = BotFaction.getHostileFactions(faction);
                source.method_9226(() -> class_2561.method_43470(" - " + faction + " (" + members.size() + " members, " + enemies.size() + " enemies)"), false);
            }
        }
        return factions.size();
    }

    private static int factionCreate(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        if (BotFaction.createFaction(name)) {
            source.method_9226(() -> class_2561.method_43470("Faction '" + name + "' created!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Faction '" + name + "' already exists!"));
            return 0;
        }
    }

    private static int factionDelete(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String name = StringArgumentType.getString(ctx, "name");
        if (BotFaction.deleteFaction(name)) {
            source.method_9226(() -> class_2561.method_43470("Faction '" + name + "' deleted!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Faction '" + name + "' not found!"));
            return 0;
        }
    }

    private static int factionAdd(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        String player = StringArgumentType.getString(ctx, "player");
        if (BotFaction.addMember(faction, player)) {
            source.method_9226(() -> class_2561.method_43470("Added '" + player + "' to faction '" + faction + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
    }

    private static int factionRemove(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        String player = StringArgumentType.getString(ctx, "player");
        if (BotFaction.removeMember(faction, player)) {
            source.method_9226(() -> class_2561.method_43470("Removed '" + player + "' from faction '" + faction + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to remove '" + player + "' from faction '" + faction + "'"));
            return 0;
        }
    }

    private static int factionHostile(CommandContext<class_2168> ctx, boolean isHostile) {
        var source = ctx.getSource();
        String faction1 = StringArgumentType.getString(ctx, "faction1");
        String faction2 = StringArgumentType.getString(ctx, "faction2");
        if (BotFaction.setHostile(faction1, faction2, isHostile)) {
            if (isHostile) {
                source.method_9226(() -> class_2561.method_43470("Factions '" + faction1 + "' and '" + faction2 + "' are now hostile!"), true);
            } else {
                source.method_9226(() -> class_2561.method_43470("Factions '" + faction1 + "' and '" + faction2 + "' are now neutral"), true);
            }
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("One or both factions not found, or same faction!"));
            return 0;
        }
    }

    private static int factionInfo(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        var members = BotFaction.getMembers(faction);
        var enemies = BotFaction.getHostileFactions(faction);
        if (members.isEmpty() && enemies.isEmpty() && !BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        source.method_9226(() -> class_2561.method_43470("=== Faction: " + faction + " ==="), false);
        source.method_9226(() -> class_2561.method_43470("Members (" + members.size() + "): " + String.join(", ", members)), false);
        source.method_9226(() -> class_2561.method_43470("Hostile to (" + enemies.size() + "): " + String.join(", ", enemies)), false);
        return 1;
    }

    private static int factionAddNear(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        double radius = DoubleArgumentType.getDouble(ctx, "radius");
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        var entity = source.method_9228();
        if (entity == null) {
            source.method_9213(class_2561.method_43470("This command must be run by a player!"));
            return 0;
        }
        int count = 0;
        var allBots = BotManager.getAllBots();
        var server = source.method_9211();
        for (String botName : allBots) {
            var bot = server.method_3760().method_14566(botName);
            if (bot != null && bot.method_5739(entity) <= radius) {
                BotFaction.addMember(faction, botName);
                count++;
            }
        }
        int finalCount = count;
        source.method_9226(() -> class_2561.method_43470("Added " + finalCount + " bots to faction '" + faction + "'"), true);
        return count;
    }

    private static int factionAddAll(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        var allBots = BotManager.getAllBots();
        int count = 0;
        for (String botName : allBots) {
            BotFaction.addMember(faction, botName);
            count++;
        }
        int finalCount = count;
        source.method_9226(() -> class_2561.method_43470("Added " + finalCount + " bots to faction '" + faction + "'"), true);
        return count;
    }

    private static int factionGive(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        String itemCommand = StringArgumentType.getString(ctx, "item");
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        var members = BotFaction.getMembers(faction);
        var server = source.method_9211();
        int count = 0;
        for (String memberName : members) {
            try {
                server.method_3734().method_9235().execute("give " + memberName + " " + itemCommand, server.method_3739());
                count++;
            } catch (Exception e) {
            }
        }
        int finalCount = count;
        source.method_9226(() -> class_2561.method_43470("Gave items to " + finalCount + " members of faction '" + faction + "'"), true);
        return count;
    }

    private static int factionAttack(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        String target = StringArgumentType.getString(ctx, "target");
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        var members = BotFaction.getMembers(faction);
        int count = 0;
        for (String memberName : members) {
            if (BotManager.getAllBots().contains(memberName)) {
                BotCombat.setTarget(memberName, target);
                count++;
            }
        }
        int finalCount = count;
        source.method_9226(() -> class_2561.method_43470("Faction '" + faction + "' (" + finalCount + " bots) attacking " + target + "!"), true);
        return count;
    }

    private static int factionStartPath(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        String path = StringArgumentType.getString(ctx, "path");
        var members = BotFaction.getMembers(faction);
        if (members.isEmpty()) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found or has no members"));
            return 0;
        }
        var botPath = BotPath.getPath(path);
        if (botPath == null) {
            source.method_9213(class_2561.method_43470("Path '" + path + "' not found"));
            return 0;
        }
        int started = 0;
        for (String member : members) {
            if (BotManager.getAllBots().contains(member)) {
                if (BotPath.startFollowing(member, path)) {
                    started++;
                }
            }
        }
        if (started > 0) {
            int finalStarted = started;
            source.method_9226(() -> class_2561.method_43470("Started path '" + path + "' for " + finalStarted + " bots in faction '" + faction + "'"), true);
            return started;
        } else {
            source.method_9213(class_2561.method_43470("No bots in faction '" + faction + "'"));
            return 0;
        }
    }

    private static int factionStopPath(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        var members = BotFaction.getMembers(faction);
        if (members.isEmpty()) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found or has no members"));
            return 0;
        }
        int stopped = 0;
        for (String member : members) {
            if (BotManager.getAllBots().contains(member)) {
                if (BotPath.stopFollowing(member)) {
                    stopped++;
                }
            }
        }
        if (stopped > 0) {
            int finalStopped = stopped;
            source.method_9226(() -> class_2561.method_43470("Stopped path for " + finalStopped + " bots in faction '" + faction + "'"), true);
            return stopped;
        } else {
            source.method_9213(class_2561.method_43470("No bots in faction '" + faction + "' were following a path"));
            return 0;
        }
    }

    private static int factionGiveKit(CommandContext<class_2168> ctx) {
        var source = ctx.getSource();
        String faction = StringArgumentType.getString(ctx, "faction");
        String kitname = StringArgumentType.getString(ctx, "kitname");
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        if (!BotKits.kitExists(kitname)) {
            source.method_9213(class_2561.method_43470("Kit '" + kitname + "' not found!"));
            return 0;
        }
        var members = BotFaction.getMembers(faction);
        if (members == null || members.isEmpty()) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' has no members!"));
            return 0;
        }
        int count = 0;
        for (String memberName : members) {
            if (BotManager.getAllBots().contains(memberName)) {
                var bot = BotManager.getBot(source.method_9211(), memberName);
                if (bot != null && BotKits.giveKit(kitname, bot)) {
                    count++;
                }
            }
        }
        int finalCount = count;
        source.method_9226(() -> class_2561.method_43470("Gave kit '" + kitname + "' to " + finalCount + " bots in faction '" + faction + "'"), true);
        return 1;
    }
}
