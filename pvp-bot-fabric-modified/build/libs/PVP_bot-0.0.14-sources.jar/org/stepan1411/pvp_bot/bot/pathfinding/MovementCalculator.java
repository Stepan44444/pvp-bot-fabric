package org.stepan1411.pvp_bot.bot.pathfinding;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;


public class MovementCalculator {
    

    public static final double WALK_ONE_BLOCK_COST = 20.0 / 4.317;
    public static final double WALK_ONE_IN_WATER_COST = 20.0 / 2.2;
    public static final double JUMP_ONE_BLOCK_COST = 20.0 / 4.0;
    public static final double FALL_N_BLOCKS_COST = 20.0 / 10.0;
    public static final double DIAGONAL_COST = WALK_ONE_BLOCK_COST * 1.414;
    public static final double CLIMB_COST = 20.0 / 2.35;
    
    private final class_1937 world;
    
    public MovementCalculator(class_1937 world) {
        this.world = world;
    }
    
    
    public List<PossibleMovement> getMovements(class_2338 from) {
        List<PossibleMovement> movements = new ArrayList<>();
        

        addTraverseMovement(movements, from, 1, 0);
        addTraverseMovement(movements, from, -1, 0);
        addTraverseMovement(movements, from, 0, 1);
        addTraverseMovement(movements, from, 0, -1);
        

        addDiagonalMovement(movements, from, 1, 1);
        addDiagonalMovement(movements, from, 1, -1);
        addDiagonalMovement(movements, from, -1, 1);
        addDiagonalMovement(movements, from, -1, -1);
        

        addPillarMovement(movements, from);
        addFallMovement(movements, from);
        

        if (isClimbable(from) || isClimbable(from.method_10084())) {
            addClimbMovement(movements, from);
        }
        
        return movements;
    }
    
    
    private void addTraverseMovement(List<PossibleMovement> movements, class_2338 from, int dx, int dz) {
        class_2338 to = from.method_10069(dx, 0, dz);
        

        if (isStairs(to)) {

            if (canPassThrough(to.method_10084()) && canPassThrough(to.method_10086(2))) {
                movements.add(new PossibleMovement(to, WALK_ONE_BLOCK_COST * 1.2, MovementType.ASCEND));
            }
            return;
        }
        

        if (canWalkOn(to)) {
            movements.add(new PossibleMovement(to, WALK_ONE_BLOCK_COST, MovementType.TRAVERSE));
            return;
        }
        

        class_2338 ascend = to.method_10084();
        if (canWalkOn(ascend) && canPassThrough(from.method_10084()) && canPassThrough(from.method_10086(2))) {
            movements.add(new PossibleMovement(ascend, JUMP_ONE_BLOCK_COST, MovementType.ASCEND));
            return;
        }
        

        class_2338 descend = to.method_10074();
        if (canWalkOn(descend)) {
            movements.add(new PossibleMovement(descend, WALK_ONE_BLOCK_COST * 1.2, MovementType.DESCEND));
        }
    }
    
    
    private void addDiagonalMovement(List<PossibleMovement> movements, class_2338 from, int dx, int dz) {
        class_2338 to = from.method_10069(dx, 0, dz);
        

        class_2338 side1 = from.method_10069(dx, 0, 0);
        class_2338 side2 = from.method_10069(0, 0, dz);
        
        if (!canPassThrough(side1) && !canPassThrough(side2)) {
            return;
        }
        
        if (canWalkOn(to)) {
            movements.add(new PossibleMovement(to, DIAGONAL_COST, MovementType.DIAGONAL));
        }
    }
    
    
    private void addPillarMovement(List<PossibleMovement> movements, class_2338 from) {
        class_2338 up = from.method_10084();
        if (canWalkOn(up) && canPassThrough(from.method_10084()) && canPassThrough(from.method_10086(2))) {
            movements.add(new PossibleMovement(up, JUMP_ONE_BLOCK_COST * 1.5, MovementType.PILLAR));
        }
    }
    
    
    private void addFallMovement(List<PossibleMovement> movements, class_2338 from) {

        for (int fallDist = 1; fallDist <= 4; fallDist++) {
            class_2338 down = from.method_10087(fallDist);
            

            boolean pathClear = true;
            for (int i = 1; i < fallDist; i++) {
                if (!canPassThrough(from.method_10087(i))) {
                    pathClear = false;
                    break;
                }
            }
            
            if (pathClear && canWalkOn(down)) {
                double cost = FALL_N_BLOCKS_COST * fallDist;
                movements.add(new PossibleMovement(down, cost, MovementType.FALL));
                break;
            }
        }
    }
    
    
    private void addClimbMovement(List<PossibleMovement> movements, class_2338 from) {
        class_2338 up = from.method_10084();
        if (isClimbable(up) && canPassThrough(up.method_10084())) {
            movements.add(new PossibleMovement(up, CLIMB_COST, MovementType.CLIMB));
        }
    }
    
    
    private boolean canWalkOn(class_2338 pos) {
        class_2680 belowState = world.method_8320(pos.method_10074());
        

        if (isStairs(pos.method_10074())) {
            return canPassThrough(pos) && canPassThrough(pos.method_10084());
        }
        

        if (!isSolid(pos.method_10074())) {
            return false;
        }
        

        if (!canPassThrough(pos) || !canPassThrough(pos.method_10084())) {
            return false;
        }
        
        return true;
    }
    
    
    private boolean canPassThrough(class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_26215() || state.method_51176() || !state.method_26212(world, pos);
    }
    
    
    private boolean isSolid(class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return !state.method_26215() && state.method_26212(world, pos);
    }
    
    
    private boolean isClimbable(class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_26204() instanceof net.minecraft.class_2399 ||
               state.method_26204() instanceof net.minecraft.class_2541 ||
               state.method_27852(net.minecraft.class_2246.field_16492) ||
               state.method_27852(net.minecraft.class_2246.field_23078) ||
               state.method_27852(net.minecraft.class_2246.field_22123);
    }
    
    
    private boolean isStairs(class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_26204() instanceof net.minecraft.class_2510;
    }
    
    
    public static class PossibleMovement {
        public final class_2338 destination;
        public final double cost;
        public final MovementType type;
        
        public PossibleMovement(class_2338 destination, double cost, MovementType type) {
            this.destination = destination;
            this.cost = cost;
            this.type = type;
        }
    }
}
