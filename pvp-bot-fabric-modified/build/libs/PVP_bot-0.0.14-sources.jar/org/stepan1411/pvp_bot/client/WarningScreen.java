package org.stepan1411.pvp_bot.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class WarningScreen extends class_437 {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("PVP_BOT_WARNING");
    private static final class_2960 WARNING_TEXTURE = class_2960.method_60655("pvp_bot", "textures/gui/warning.png");
    
    private final class_437 parent;
    private final Path warningFile;
    private class_4286 dontShowAgain;
    private boolean textureLogged = false;
    
    public WarningScreen(class_437 parent) {
        super(class_2561.method_43470("WARNING: This mod is unstable in singleplayer!"));
        this.parent = parent;
        Path configDir = FabricLoader.getInstance().getConfigDir().resolve("pvpbot");
        this.warningFile = configDir.resolve("no_singleplayer_warning.txt");
    }
    
    @Override
    protected void method_25426() {
        super.method_25426();
        
        if (!textureLogged) {
            LOGGER.info("Initializing warning screen");
            LOGGER.info("Texture identifier: {}", WARNING_TEXTURE);
            textureLogged = true;
        }
        
        int centerX = this.field_22789 / 2;
        

        int bottomY = this.field_22790 - 60;
        

        this.dontShowAgain = class_4286.method_54787(class_2561.method_43470("Don't show again"), this.field_22793)
                .method_54789(centerX - 60, bottomY)
                .method_54788();
        this.method_37063(dontShowAgain);
        

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("OK"),
                button -> {
                    if (dontShowAgain.method_20372()) {
                        try {
                            Files.createDirectories(warningFile.getParent());
                            Files.writeString(warningFile, "User disabled singleplayer warning");
                            LOGGER.info("Warning disabled by user");
                        } catch (IOException ex) {
                            LOGGER.error("Failed to save warning preference", ex);
                        }
                    }
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(parent);
                    }
                }
        ).method_46434(centerX - 40, bottomY + 30, 80, 20).method_46431());
    }
    
    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {

    }
    
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {

        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF000000);
        

        int displayHeight = this.field_22790;
        int displayWidth = displayHeight;
        int imageX = (this.field_22789 - displayWidth) / 2;
        int imageY = 0;
        
        try {


            context.method_25302(
                class_10799.field_56883,
                WARNING_TEXTURE,
                imageX, imageY,
                0, 0,
                displayWidth, displayHeight,
                1024, 1024,
                1024, 1024
            );
        } catch (Exception e) {
            if (!textureLogged) {
                LOGGER.error("Failed to render warning texture", e);
                textureLogged = true;
            }

            context.method_25294(imageX, imageY, imageX + displayWidth, imageY + displayHeight, 0xFFFF0000);
            

            context.method_25300(
                this.field_22793,
                "Failed to load warning image",
                this.field_22789 / 2,
                this.field_22790 / 2,
                0xFFFFFF
            );
        }
        

        super.method_25394(context, mouseX, mouseY, delta);
    }
    
    @Override
    public boolean method_25422() {
        return true;
    }
    
    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}
