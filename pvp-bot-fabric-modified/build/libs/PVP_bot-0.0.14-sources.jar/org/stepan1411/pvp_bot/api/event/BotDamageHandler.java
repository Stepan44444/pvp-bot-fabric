package org.stepan1411.pvp_bot.api.event;

import net.minecraft.class_1297;
import net.minecraft.class_3222;


@FunctionalInterface
public interface BotDamageHandler {
    
    boolean onBotDamage(class_3222 bot, class_1297 attacker, float damage);
}
