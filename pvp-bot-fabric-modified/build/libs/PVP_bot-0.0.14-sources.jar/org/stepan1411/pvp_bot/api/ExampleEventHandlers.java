package org.stepan1411.pvp_bot.api;

import net.minecraft.class_2561;
import org.stepan1411.pvp_bot.api.event.BotEventManager;


public class ExampleEventHandlers {
    
    
    public static void register() {
        BotEventManager eventManager = PvpBotAPI.getEventManager();
        

        eventManager.registerSpawnHandler(bot -> {
            System.out.println("[PVP_BOT_API] Example: Bot " + bot.method_5477().getString() + " spawned!");
            bot.method_64398(class_2561.method_43470("§a[API] Welcome! API is working correctly."));
        });
        

        eventManager.registerDeathHandler(bot -> {
            System.out.println("[PVP_BOT_API] Example: Bot " + bot.method_5477().getString() + " died!");
        });
        

        eventManager.registerAttackHandler((bot, target) -> {

            if (target.method_5864().toString().contains("villager")) {
                bot.method_64398(class_2561.method_43470("§c[API] Cannot attack villagers!"));
                return true;
            }
            

            System.out.println("[PVP_BOT_API] Example: " + bot.method_5477().getString() + 
                             " attacking " + target.method_5477().getString());
            return false;
        });
        

        eventManager.registerDamageHandler((bot, attacker, damage) -> {

            if (attacker == null && damage > 5.0f) {
                bot.method_64398(class_2561.method_43470("§e[API] Fall damage reduced!"));


                System.out.println("[PVP_BOT_API] Example: Reduced fall damage for " + 
                                 bot.method_5477().getString() + " from " + damage + " to " + (damage * 0.5f));
            }
            
            return false;
        });
        

        eventManager.registerTickHandler(bot -> {

            if (bot.field_6012 % 20 == 0) {

                if (bot.method_6032() < bot.method_6063() && bot.field_6012 % 100 == 0) {
                    float newHealth = Math.min(bot.method_6063(), bot.method_6032() + 0.5f);
                    bot.method_6033(newHealth);
                    
                    if (bot.field_6012 % 200 == 0) {
                        System.out.println("[PVP_BOT_API] Example: Slow healing for " + 
                                         bot.method_5477().getString() + " (Health: " + newHealth + ")");
                    }
                }
            }
        });
        
        System.out.println("[PVP_BOT_API] Example event handlers registered successfully!");
    }
}