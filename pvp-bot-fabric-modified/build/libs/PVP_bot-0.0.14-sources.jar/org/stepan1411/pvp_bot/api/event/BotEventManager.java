package org.stepan1411.pvp_bot.api.event;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_3222;


public class BotEventManager {
    
    private static final BotEventManager INSTANCE = new BotEventManager();
    
    private final List<BotSpawnHandler> spawnHandlers = new ArrayList<>();
    private final List<BotDeathHandler> deathHandlers = new ArrayList<>();
    private final List<BotAttackHandler> attackHandlers = new ArrayList<>();
    private final List<BotDamageHandler> damageHandlers = new ArrayList<>();
    private final List<BotTickHandler> tickHandlers = new ArrayList<>();
    
    private BotEventManager() {}
    
    
    public static BotEventManager getInstance() {
        return INSTANCE;
    }
    
    
    public void registerSpawnHandler(BotSpawnHandler handler) {
        if (handler != null) {
            spawnHandlers.add(handler);
        }
    }
    
    
    public void registerDeathHandler(BotDeathHandler handler) {
        if (handler != null) {
            deathHandlers.add(handler);
        }
    }
    
    
    public void registerAttackHandler(BotAttackHandler handler) {
        if (handler != null) {
            attackHandlers.add(handler);
        }
    }
    
    
    public void registerDamageHandler(BotDamageHandler handler) {
        if (handler != null) {
            damageHandlers.add(handler);
        }
    }
    
    
    public void registerTickHandler(BotTickHandler handler) {
        if (handler != null) {
            tickHandlers.add(handler);
        }
    }
    
    
    public void fireSpawnEvent(class_3222 bot) {
        for (BotSpawnHandler handler : spawnHandlers) {
            try {
                handler.onBotSpawn(bot);
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in spawn handler: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
    
    public void fireDeathEvent(class_3222 bot) {
        for (BotDeathHandler handler : deathHandlers) {
            try {
                handler.onBotDeath(bot);
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in death handler: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
    
    public boolean fireAttackEvent(class_3222 bot, class_1297 target) {
        boolean cancelled = false;
        for (BotAttackHandler handler : attackHandlers) {
            try {
                if (handler.onBotAttack(bot, target)) {
                    cancelled = true;
                }
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in attack handler: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return cancelled;
    }
    
    
    public boolean fireDamageEvent(class_3222 bot, class_1297 attacker, float damage) {
        boolean cancelled = false;
        for (BotDamageHandler handler : damageHandlers) {
            try {
                if (handler.onBotDamage(bot, attacker, damage)) {
                    cancelled = true;
                }
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in damage handler: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return cancelled;
    }
    
    
    public void fireTickEvent(class_3222 bot) {
        for (BotTickHandler handler : tickHandlers) {
            try {
                handler.onBotTick(bot);
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in tick handler: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
    
    public int getSpawnHandlerCount() {
        return spawnHandlers.size();
    }
    
    
    public int getDeathHandlerCount() {
        return deathHandlers.size();
    }
    
    
    public int getAttackHandlerCount() {
        return attackHandlers.size();
    }
    
    
    public int getDamageHandlerCount() {
        return damageHandlers.size();
    }
    
    
    public int getTickHandlerCount() {
        return tickHandlers.size();
    }
    
    
    public void clearAllHandlers() {
        spawnHandlers.clear();
        deathHandlers.clear();
        attackHandlers.clear();
        damageHandlers.clear();
        tickHandlers.clear();
    }
}
