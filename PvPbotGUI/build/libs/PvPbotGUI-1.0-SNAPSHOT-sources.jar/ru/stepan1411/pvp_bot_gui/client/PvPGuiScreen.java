package ru.stepan1411.pvp_bot_gui.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import ru.stepan1411.pvp_bot_gui.client.network.BotPayloads;
import ru.stepan1411.pvp_bot_gui.client.network.SettingsPayloads;
import org.stepan1411.sgl.gui.BaseGuiScreen;
import org.stepan1411.sgl.gui.Notification;
import org.stepan1411.sgl.gui.Surface;
import org.stepan1411.sgl.gui.components.StyledButton;
import org.stepan1411.sgl.gui.components.StyledLabel;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PvPGuiScreen {
    private static Map<String, String> cachedSettings;
    private static List<String> cachedBotList;

    public static void open() {
        class_310 client = class_310.method_1551();
        if (client.method_1562() != null) {
            client.method_1507(new LoadingScreen());
            ClientPlayNetworking.send(new SettingsPayloads.SettingsRequestPayload());
            return;
        }
        client.method_1507(new ErrorScreen("§cNot connected to a server"));
    }

    public static void onSettingsReceived(Map<String, String> settings) {
        cachedSettings = new LinkedHashMap<>(settings);
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            class_437 current = client.field_1755;
            if (current instanceof LoadingScreen) {
                client.method_1507(new MainScreen());
            }
        });
    }

    public static void onBotListReceived(List<String> botNames) {
        cachedBotList = botNames;
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            if (client.field_1755 instanceof BotsScreen) {
                client.method_1507(new BotsScreen(botNames));
            }
        });
    }

    private static class MainScreen extends BaseGuiScreen {
        MainScreen() {
            super(class_2561.method_43470("PvP Bot"));
        }

        @Override
        protected void method_25426() {
            super.method_25426();
            int panelW = 340;
            int panelH = 280;
            int pX = (field_22789 - panelW) / 2;
            int pY = (field_22790 - panelH) / 2;

            setPanelBounds(pX, pY, panelW, panelH);
            enableScroll(false);

            int cx = pX + 30;
            int btnW = panelW - 60;
            int cy = pY + 55;
            int btnH = 32;
            int gap = 8;

            StyledButton spawnBtn = new StyledButton(cx, cy, btnW, btnH, class_2561.method_43470("§lSpawn Bot"));
            spawnBtn.surface(Surface.flat(0xFF006600));
            spawnBtn.onPress(() -> {
                class_310 mc = class_310.method_1551();
                if (mc.method_1562() != null) {
                    mc.method_1562().method_45729("/pvpbot spawn");
                }
                cachedBotList = null;
            });
            method_37063(spawnBtn);
            cy += btnH + gap;

            StyledButton botsBtn = new StyledButton(cx, cy, btnW, btnH,
                class_2561.method_43470("§lBots" + (cachedBotList != null ? " §7(" + cachedBotList.size() + ")" : "")));
            botsBtn.surface(Surface.flat(0xFF444444));
            botsBtn.onPress(() -> {
                ClientPlayNetworking.send(new BotPayloads.BotListRequestPayload());
                field_22787.method_1507(new BotsScreen(cachedBotList));
            });
            method_37063(botsBtn);
            cy += btnH + gap;

            StyledButton settingsBtn = new StyledButton(cx, cy, btnW, btnH, class_2561.method_43470("§lSettings"));
            settingsBtn.surface(Surface.flat(0xFF444444));
            settingsBtn.onPress(() -> {
                if (cachedSettings != null) {
                    field_22787.method_1507(new SettingsPage(cachedSettings));
                }
            });
            method_37063(settingsBtn);
        }

        @Override
        protected void renderContent(class_332 context, int mouseX, int mouseY, float delta) {
            int panelW = 340;
            int panelH = 280;
            int pX = (field_22789 - panelW) / 2;
            int pY = (field_22790 - panelH) / 2;

            context.method_25294(pX, pY, pX + panelW, pY + panelH, 0xB0303030);
            context.method_25294(pX, pY, pX + panelW, pY + 1, 0xFF505050);
            context.method_25294(pX, pY + panelH - 1, pX + panelW, pY + panelH, 0xFF505050);
            context.method_25294(pX, pY, pX + 1, pY + panelH, 0xFF505050);
            context.method_25294(pX + panelW - 1, pY, pX + panelW, pY + panelH, 0xFF505050);

            class_2561 titleText = class_2561.method_43470("§lPvP Bot");
            context.method_51439(field_22793, titleText, (field_22789 - field_22793.method_27525(titleText)) / 2, pY + 14, 0xFFFFAA00, true);
        }
    }

    private static class BotsScreen extends BaseGuiScreen {
        private List<String> botNames;

        BotsScreen(List<String> botNames) {
            super(class_2561.method_43470("Bots"));
            this.botNames = botNames;
        }

        @Override
        protected void method_25426() {
            super.method_25426();
            int panelW = 340;
            int panelH = 320;
            int pX = (field_22789 - panelW) / 2;
            int pY = (field_22790 - panelH) / 2;

            setPanelBounds(pX, pY, panelW, panelH);
            enableScroll(true);
            setScrollbarColors(0xFF222222, 0xFF999999);

            int cx = pX + 15;
            int btnW = panelW - 30;
            int cy = pY + 40;
            int btnH = 22;
            int gap = 4;

            if (botNames == null) {
                StyledLabel loading = new StyledLabel(cx, cy, btnW, 20, class_2561.method_43470("§eLoading bots..."));
                loading.color(0xFFFFAA00);
                registerScrollable(loading);
                cy += 22 + gap;
            } else if (botNames.isEmpty()) {
                StyledLabel empty = new StyledLabel(cx, cy, btnW, 20, class_2561.method_43470("§7No bots spawned"));
                empty.color(0xFF888888);
                registerScrollable(empty);
                cy += 22 + gap;
            } else {
                for (String name : botNames) {
                    StyledButton botBtn = new StyledButton(cx, cy, btnW, btnH,
                        class_2561.method_43470("§e" + name));
                    botBtn.surface(Surface.flat(0xFF2A2A2A));
                    botBtn.onPress(() -> showBotNotification(name));
                    registerScrollable(botBtn);
                    cy += btnH + gap;
                }
            }

            cy += 6;
            StyledButton backBtn = new StyledButton(cx + btnW / 2 - 40, cy, 80, btnH, class_2561.method_43470("Back"));
            backBtn.surface(Surface.flat(0xFF444444));
            backBtn.onPress(() -> field_22787.method_1507(new MainScreen()));
            registerScrollable(backBtn);
            cy += btnH + gap;

            setContentHeight(cy - pY);
        }

        private void showBotNotification(String name) {
            showNotification(new Notification(class_2561.method_43470("§e" + name),
                new Notification.Action(class_2561.method_43470("§cKill"), () -> {
                    ClientPlayNetworking.send(new BotPayloads.BotActionPayload(name, "KILL"));
                    dismissNotification();
                }),
                new Notification.Action(class_2561.method_43470("§aHeal"), () -> {
                    ClientPlayNetworking.send(new BotPayloads.BotActionPayload(name, "HEAL"));
                    dismissNotification();
                }),
                new Notification.Action(class_2561.method_43470("§eClear Inventory"), () -> {
                    ClientPlayNetworking.send(new BotPayloads.BotActionPayload(name, "CLEAR_INVENTORY"));
                    dismissNotification();
                }),
                new Notification.Action(class_2561.method_43470("§6Give Kit"), () -> {
                    ClientPlayNetworking.send(new BotPayloads.BotActionPayload(name, "GIVE_KIT"));
                    dismissNotification();
                }),
                new Notification.Action(class_2561.method_43470("§bTP to Me"), () -> {
                    ClientPlayNetworking.send(new BotPayloads.BotActionPayload(name, "TP_TO_ME"));
                    dismissNotification();
                })
            ));
        }

        @Override
        protected void renderContent(class_332 context, int mouseX, int mouseY, float delta) {
            int panelW = 340;
            int panelH = 320;
            int pX = (field_22789 - panelW) / 2;
            int pY = (field_22790 - panelH) / 2;

            context.method_25294(pX, pY, pX + panelW, pY + panelH, 0xB0303030);
            context.method_25294(pX, pY, pX + panelW, pY + 1, 0xFF505050);
            context.method_25294(pX, pY + panelH - 1, pX + panelW, pY + panelH, 0xFF505050);
            context.method_25294(pX, pY, pX + 1, pY + panelH, 0xFF505050);
            context.method_25294(pX + panelW - 1, pY, pX + panelW, pY + panelH, 0xFF505050);

            context.method_51439(field_22793, class_2561.method_43470("§lBots"), pX + 15, pY + 12, 0xFFFFFFFF, true);
        }
    }

    private static class SettingsPage extends BaseGuiScreen {
        private final Map<String, String> settings;

        SettingsPage(Map<String, String> settings) {
            super(class_2561.method_43470("Settings"));
            this.settings = settings;
        }

        @Override
        protected void method_25426() {
            super.method_25426();
            int panelW = 340;
            int panelH = 320;
            int pX = (field_22789 - panelW) / 2;
            int pY = (field_22790 - panelH) / 2;

            setPanelBounds(pX, pY, panelW, panelH);
            enableScroll(true);
            setScrollbarColors(0xFF222222, 0xFF999999);

            int cx = pX + 15;
            int cy = pY + 35;
            int btnW = panelW - 30;
            int btnH = 20;
            int gap = 4;

            if (settings != null) {
                for (Map.Entry<String, String> entry : settings.entrySet()) {
                    String key = entry.getKey();
                    String val = entry.getValue();

                    if (val.equals("true") || val.equals("false")) {
                        boolean isOn = val.equals("true");
                        String name = formatKey(key);
                        StyledButton btn = new StyledButton(cx, cy, btnW, btnH,
                            class_2561.method_43470(name + ": " + (isOn ? "§aON" : "§cOFF")));
                        btn.surface(isOn ? Surface.flat(0xFF006600) : Surface.flat(0xFF444444));
                        btn.onPress(() -> {
                            boolean newVal = !isOn;
                            cachedSettings.put(key, String.valueOf(newVal));
                            ClientPlayNetworking.send(new SettingsPayloads.SettingsUpdatePayload(key, String.valueOf(newVal)));
                            btn.method_25355(class_2561.method_43470(name + ": " + (newVal ? "§aON" : "§cOFF")));
                            btn.surface(newVal ? Surface.flat(0xFF006600) : Surface.flat(0xFF444444));
                        });
                        registerScrollable(btn);
                        cy += btnH + gap;
                    } else {
                        StyledLabel label = new StyledLabel(cx, cy, btnW, btnH,
                            class_2561.method_43470(formatKey(key) + ": " + val));
                        label.color(0xFFCCCCCC);
                        registerScrollable(label);
                        cy += btnH + gap;
                    }
                }
            }

            cy += 6;
            StyledButton backBtn = new StyledButton(cx + btnW / 2 - 40, cy, 80, btnH, class_2561.method_43470("Back"));
            backBtn.surface(Surface.flat(0xFF444444));
            backBtn.onPress(() -> field_22787.method_1507(new MainScreen()));
            registerScrollable(backBtn);
            cy += btnH + gap;

            setContentHeight(cy - pY);
        }

        @Override
        protected void renderContent(class_332 context, int mouseX, int mouseY, float delta) {
            int panelW = 340;
            int panelH = 320;
            int pX = (field_22789 - panelW) / 2;
            int pY = (field_22790 - panelH) / 2;

            context.method_25294(pX, pY, pX + panelW, pY + panelH, 0xB0303030);
            context.method_25294(pX, pY, pX + panelW, pY + 1, 0xFF505050);
            context.method_25294(pX, pY + panelH - 1, pX + panelW, pY + panelH, 0xFF505050);
            context.method_25294(pX, pY, pX + 1, pY + panelH, 0xFF505050);
            context.method_25294(pX + panelW - 1, pY, pX + panelW, pY + panelH, 0xFF505050);

            context.method_51439(field_22793, class_2561.method_43470("§lSettings"), pX + 15, pY + 12, 0xFFFFFFFF, true);
        }
    }

    private static String formatKey(String camelCase) {
        StringBuilder sb = new StringBuilder();
        for (char c : camelCase.toCharArray()) {
            if (Character.isUpperCase(c) && sb.length() > 0) sb.append(' ');
            sb.append(c);
        }
        return sb.toString();
    }

    private static class LoadingScreen extends class_437 {
        private int ticks;

        protected LoadingScreen() {
            super(class_2561.method_43470("PvP Bot GUI"));
        }

        @Override
        public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
            context.method_25294(0, 0, field_22789, field_22790, 0xCC000000);
        }

        @Override
        public void method_25393() {
            ticks++;
            if (ticks > 100) {
                class_310.method_1551().method_1507(new ErrorScreen("§cServer not responding"));
            }
        }

        @Override
        public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
            method_25420(context, mouseX, mouseY, delta);
            String status = ticks < 20 ? "§eConnecting" : "§eLoading settings";
            int dots = (ticks / 10) % 4;
            class_2561 text = class_2561.method_43470(status + ".".repeat(dots) + " ".repeat(3 - dots));
            int x = (field_22789 - field_22793.method_27525(text)) / 2;
            context.method_51439(field_22793, text, x, field_22790 / 2 - 10, 0xFFFFFF, true);
        }
    }

    private static class ErrorScreen extends class_437 {
        private final String message;

        protected ErrorScreen(String message) {
            super(class_2561.method_43470("PvP Bot GUI"));
            this.message = message;
        }

        @Override
        public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
            context.method_25294(0, 0, field_22789, field_22790, 0xCC000000);
        }

        @Override
        protected void method_25426() {
            int y = field_22790 / 2 - 20;
            method_37063(class_4185.method_46430(class_2561.method_43470("Retry"), btn -> open())
                .method_46434(field_22789 / 2 - 50, y + 30, 100, 20).method_46431());
        }

        @Override
        public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
            method_25420(context, mouseX, mouseY, delta);
            class_2561 text = class_2561.method_43470(message);
            int x = (field_22789 - field_22793.method_27525(text)) / 2;
            context.method_51439(field_22793, text, x, field_22790 / 2 - 20, 0xFFFFFF, true);
            super.method_25394(context, mouseX, mouseY, delta);
        }
    }
}
